import java.util.Hashtable;


public class MarkNodes {

	Hashtable<Long, Node> hashTable  =null;
	public MarkNodes()
	{
		hashTable = null;
		hashTable = new Hashtable<>();
	}
	public Node getMarkNode(Long id )
	{
		return hashTable.get(new Long(id));
	}
	public void insert(Long id,Node node)
	{
		this.hashTable.put(id, node);
	}

}

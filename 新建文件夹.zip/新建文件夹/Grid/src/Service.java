import java.util.ArrayList;

public class Service {
	protected long s = 0;
	protected long d = 0;
	private long id = 0; 

   
	private ArrayList<Integer> services = new ArrayList<Integer>();//�ṩ����
	
    public Service(String line) {
		
		String s=line;
		
	    String s1[]=s.split(" ");//ÿһ�е����ݶ���ŵ�һ��������,�Կո�ָ�
		long pID=Long.parseLong(s1[0]);
		long x=Long.parseLong(s1[1]);
		long y=Long.parseLong(s1[2]);
		for(int i=3;i<s1.length;i++){
			services.add(Integer.parseInt(s1[i]));
		}
		this.id = pID;
		this.s = x;
		this.d = y;
		this.services=services;
	}

    public Service(long id,long s,long d)
    {
        this.id = id;
        this.s = s;
        this.d = d;
       
    }
   
	public Service(long id,long s,long d, ArrayList<Integer> services) {
		this.id = id;
		this.s = s;
	    this.d = d;
	    this.services=services;
	}
	
	public long getId() {
		return id;
	}
	public void setID (long newID) {
		id = newID;
	}
	public long getS()
	{
		return s;
	}
	public void setS(long s)
	{
		this.s = s ;
	}
	public long getD()
	{
		return d;
	}
	public void setD(long d)
	{
		this.d = d;
	}
	

	public ArrayList<Integer> getServices() {
		return services;
	}

	public void setServices(ArrayList<Integer> services) {
		this.services=services;
	}



}




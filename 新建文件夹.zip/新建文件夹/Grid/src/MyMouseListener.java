import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.io.DataOutputStream;
import java.io.PrintStream;
import javax.swing.event.MouseInputAdapter;
import javax.swing.event.MouseInputListener;
public class MyMouseListener extends MouseInputAdapter implements MouseInputListener
{
	private int prex=0;
	private int prey=0;
	private int dragx=0;
	private int dragy=0;
	private DataOutputStream data=null;
	private PrintStream p=null;
	private Main window=null;
	public MyMouseListener(Main window) {
		// TODO Auto-generated constructor stub
		
		this.window=window;
	}
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		this.prex=e.getX();
		this.prey=e.getY();
		this.dragx=e.getX();
		this.dragy=e.getY();
		//System.out.print(e.getX()+" ");
		window.setCursor (Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
	}

//	@Override
	/*public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
		if((e.getX()-prex)<-10)
			window.setCurX(window.getCurX() + window.getMap().getWidth() / 4 * (window.getScale()));
		else
			if((e.getX()-prex)>10)
			window.setCurX(window.getCurX() - window.getMap().getWidth() / 4 * (window.getScale()));
			
				if((e.getY()-prey)>10)
			window.setCurY(window.getCurY() - window.getMap().getHeight()/ 4 * (window.getScale()));
				else
					if((e.getY()-prey)<-10)
			window.setCurY(window.getCurY() + window.getMap().getHeight() / 4 * (window.getScale()));
		window.repaint();		
	}
	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		if(e.getWheelRotation()<0)
		{
			window.zoomin();
		}else
		{
			window.zoomout();
		}
		window.repaint();
		super.mouseWheelMoved(e);
	}
	
*/
	
}

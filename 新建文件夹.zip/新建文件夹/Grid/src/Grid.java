import java.util.ArrayList;

public class Grid {
	protected int x = 0;
	protected int y = 0;
	private long id = 0; 
	private long gridName = 0;
    private double minx=0.0, miny=0.0, maxx=0.0, maxy=0.0;
    
	public Grid (int gridName, long id, int x, int y)
	{
		this.gridName=gridName;
		this.id = id;
		this.x = x;
		this.y = y;
	
	}

	
	public Grid(String line) {
		
		String s=line;
		
		String s1[]=s.split(" ");//ÿһ�е����ݶ���ŵ�һ��������,�Կո�ָ�
		long gridName=Long.parseLong(s1[0]);
		long pID=Long.parseLong(s1[1]);
		int x=(int)(Double.parseDouble(s1[2]));
		int y=(int)(Double.parseDouble(s1[3]));
		double minx=Double.parseDouble(s1[4]);
		double maxx=Double.parseDouble(s1[5]);
		double miny=Double.parseDouble(s1[6]);
		double maxy=Double.parseDouble(s1[7]);
		this.gridName=gridName;
		this.id = pID;
		this.x = x;
		this.y = y;
		this.minx=minx;
		this.maxx=maxx;
		this.miny=miny;
		this.maxy=maxy;
	}
	public long getGridName() {
		return gridName;
	}
	public void setGridName (int newGridName) {
		gridName = newGridName;
	}
	public long getId() {
		return id;
	}
	public void setID (long newID) {
		id = newID;
	}
	public int getX()
	{
		return x;
	}
	public void setX(int x)
	{
		this.x = x ;
	}
	public int getY()
	{
		return y;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	public double getMinx()
	{
		return minx;
	}
	public void setMinx(int minx)
	{
		this.minx = minx;
	}
	public double getMaxx()
	{
		return maxx;
	}
	public void setMaxx(int maxx)
	{
		this.maxx = maxx;
	}
	public double getMiny()
	{
		return miny;
	}
	public void setMiny(int miny)
	{
		this.miny = miny;
	}
	public double getMaxy()
	{
		return maxy;
	}
	public void setMaxy(int maxy)
	{
		this.maxy = maxy;
	
	}
}


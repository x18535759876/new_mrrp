
import java.util.ArrayList;

public class Service {

	private long id = 0; 

   
	private ArrayList<Integer> services = new ArrayList<Integer>();//�ṩ����
	
    public Service(String line) {
		
		String s=line;
		
	    String s1[]=s.split("\t");//ÿһ�е����ݶ���ŵ�һ��������,�Կո�ָ�
		long pID=Long.parseLong(s1[0]);
	
		for(int i=1;i<s1.length;i++){
			services.add(Integer.parseInt(s1[i]));
		}
		this.id = pID;
		
		this.services=services;
	}

	public Service(long id,ArrayList<Integer> services) {
		this.id = id;
	    this.services=services;
	}
	
	public long getId() {
		return id;
	}
	public void setID (long newID) {
		id = newID;
	}
	
	public ArrayList<Integer> getServices() {
		return services;
	}

	public void setServices(ArrayList<Integer> services) {
		this.services=services;
	}

	public Object getSpd() {
		// TODO �Զ����ɵķ������
		return null;
	}
   

}



import java.util.ArrayList;
import java.util.HashMap;

public class Grid {
	protected int x = 0;
	protected int y = 0;
	private long id = 0; 
	private long gridName = 0;
    private double minx=0.0, miny=0.0, maxx=0.0, maxy=0.0;
    protected HashMap<Integer,Integer> service=null;
    
	public Grid (int gridName, long id, int x, int y,HashMap<Integer,Integer> service)
	{
		this.gridName=gridName;
		this.id = id;
		this.x = x;
		this.y = y;
	    this.service=service;
	}

	
	public Grid(String line) {
		
		String s=line;
		
		String s1[]=s.split(" ");//每一行的数据都存放到一个数组中,以空格分隔
		long gridName=Long.parseLong(s1[0]);
		long pID=Long.parseLong(s1[1]);
		int x=(int)(Double.parseDouble(s1[2]));
		int y=(int)(Double.parseDouble(s1[3]));
		double minx=Double.parseDouble(s1[4]);
		double maxx=Double.parseDouble(s1[5]);
		double miny=Double.parseDouble(s1[6]);
		double maxy=Double.parseDouble(s1[7]);
		this.gridName=gridName;
		this.id = pID;
		this.x = x;
		this.y = y;
		this.minx=minx;
		this.maxx=maxx;
		this.miny=miny;
		this.maxy=maxy;
	}
/*    public void Grid1(String line) {
    	
		String s=line;
		
		String s1[]=s.split(" ");//每一行的数据都存放到一个数组中,以空格分隔
		
    	long gridName=Long.parseLong(s1[0]);
		//for(String s : str.trim().split(" ")){
		
		
		String[] ss=s1[1].split(",");
		service.put(Integer.valueOf(ss[0]), Integer.valueOf(ss[1]) );
		
		//     }
		
	//	s.substring(1,s.length-1);//去掉括号
		string[] kvs = s.split(",");//拆成key 和value 的组合
		for(string kv:kvs){
			service.put(kv.substring(0,s.indexof('=')),kv.substring(s.indexof('=')+1));
		//拆成key 和value 分别放好
		}
		
		this.service=service;
	}*/
	public long getGridName() {
		return gridName;
	}
	public void setGridName (int newGridName) {
		gridName = newGridName;
	}
	public long getId() {
		return id;
	}
	public void setID (long newID) {
		id = newID;
	}
	public int getX()
	{
		return x;
	}
	public void setX(int x)
	{
		this.x = x ;
	}
	public int getY()
	{
		return y;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	public double getMinx()
	{
		return minx;
	}
	public void setMinx(int minx)
	{
		this.minx = minx;
	}
	public double getMaxx()
	{
		return maxx;
	}
	public void setMaxx(int maxx)
	{
		this.maxx = maxx;
	}
	public double getMiny()
	{
		return miny;
	}
	public void setMiny(int miny)
	{
		this.miny = miny;
	}
	public double getMaxy()
	{
		return maxy;
	}
	public void setMaxy(int maxy)
	{
		this.maxy = maxy;
	
	}
	public HashMap<Integer,Integer> getServices(){
		return service;
	}
	public void setService(HashMap<Integer,Integer> service)
	{
		this.service = service;
	
	}
}


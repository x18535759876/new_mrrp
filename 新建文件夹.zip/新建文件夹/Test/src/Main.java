import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import java.lang.Double;
import java.security.Provider.Service;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Main extends JFrame implements ActionListener {
	public static ArrayList<Integer> request = new ArrayList<Integer>();
	public static void scanner() {
		for(int i=0;i<5;i++){
			/*Scanner StartPoint = new Scanner(System.in);
			Integer n = StartPoint.nextInt();*/
			Random ne3=new Random();
			int n= ne3.nextInt(20);
			if(!request.contains(n)){
			request.add(n);
			}
		}
	}
	public static ArrayList<Integer> request1 = new ArrayList<Integer>();
	public static ArrayList<Long> poi = new ArrayList<Long>();
	private Color c[] = null;
	private int scale = 20;// ���Ų���
	static int gridnum=0;
	static TreeMap<String,TreeMap<String,Integer>>  tmp1 = new TreeMap<String,TreeMap<String,Integer>>();
	static double Eujilide=0.0;
	//Scanner input = new Scanner(System.in);
	int n = 5; // �������n��ֵ
	//static Random ne1=new Random();
	static long s;
	//static Random ne2=new Random();
	static long d;
	/*long s=3961;
	long d=934;*/
	static long start,end,time;
	/*Scanner StartPoint = new Scanner(System.in);
	long s = StartPoint.nextLong(); // ����
	Scanner EndPoint = new Scanner(System.in);
	long d = EndPoint.nextLong(); // ����
*/	ArrayList<Long> nodeid = new ArrayList<Long>();// ���������node
	ArrayList<Integer> service = new ArrayList<Integer>();// ��������ķ���
	// �û����������
	HashMap<Long, Integer> servicepoi = new HashMap<>();// �ṩ����ĵ�
	int servicenum = 0;
	HashMap<Integer, ArrayList<Node>> requestpoi = new HashMap<>();// �ṩ����ĵ�
	HashMap<Long, HashMap<Integer,ArrayList<Long>>> Services = new HashMap<>();
	//int requestnum = 0;
	HashMap<Long, Double> servicegate = new HashMap<>();// �ṩ����ĵ�
	HashMap<Long, Double> servicesp = new HashMap<>();// �ṩ����ĵ�
	double visitgate = 0.0;
	static ArrayList<Node> visitpoi = new ArrayList<Node>();// ��Ҫ���ʵĽڵ�
	static ArrayList<Node> mustpoi = new ArrayList<Node>();
    ArrayList<Node> mustpoi3 = new ArrayList<Node>();
	ArrayList<Node> mustpoi1 = new ArrayList<Node>();
	ArrayList<Node> mustpoi2 = new ArrayList<Node>();
	ArrayList<Node> rs = new ArrayList<Node>();
	
	HashMap<Node, Double> mustpoiEujilide = new HashMap<>();// �Ա��뾭���ĵ����ŷ���������
	HashMap<Node, Double> mustpoiEujilide1 = new HashMap<>();// �Ա��뾭���ĵ����ŷ���������
	// HashMap<Node, Double> mustpoiEujilide1 = new HashMap<>();
	Queue<Double> queue1 = new PriorityQueue<>(new Comparator<Double>() {// ������ȶ��ж�ֻ��һ�����ṩ����ĵ����ŷ�Ͼ�������

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO �Զ����ɵķ������
			return (int) (arg0 - arg1);
		}

	});
	Queue<Double> queue2 = new PriorityQueue<>(new Comparator<Double>() {// ������ȶ��ж�ֻ��һ�����ṩ����ĵ����ŷ�Ͼ�������

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO �Զ����ɵķ������
			return (int) (arg0 - arg1);
		}

	});
	private JButton buttonUp = null; // �����ƶ�
	private JButton buttonDown = null; // �����ƶ�
	private JButton buttonLeft = null; // �����ƶ�
	private JButton buttonright = null; // �����ƶ�
	private JButton buttonupleft = null; // �����Ϸ��ƶ�
	private JButton buttonupright = null; // �����Ϸ��ƶ�
	private JButton buttondownleft = null; // �����·��ƶ�
	private JButton buttondownright = null; // �����·��ƶ�
	private JButton buttongrid = null; // ���������Լ��洢�����ڽڵ���Ϣ

	private Image oimg = null;
	private Graphics og = null; // Graphics�࣬�����󴫸�paint�������ʣ�drawline����ֱ��
	private JLabel map = null;
	private Nodes nodes = null; // ����ļ��еĽڵ���Ϣ��
	private Edges edges = null; // ���ļ��еĽڵ���Ϣ��ȡ��nodes�к�
//	private Services services = null;
	private Hashtable<Long, Node> pois = new Hashtable<Long, Node>();
	public static ArrayList<String> Request = new ArrayList<>();// ��������
	private Grids grids = null;
    private Services services = null; // ����ļ��еĽڵ���Ϣ��
    protected MyDataInputFile serviceIn = null;
	private int curX;
	private int curY; // ��������任
	private JPanel keys = null; // ��ť����
	protected MyDataInputFile edgeIn = null; // һ��һ�ж�ȡ�ļ�ʱ�Ͳ���ÿ�ζ�ȥ�ļ��ж�ȡ�ˣ�������IO������
	protected MyDataInputFile nodeIn = null;
	protected MyDataInputFile nodeServiceIn = null;
	protected MyDataInputFile weightIn = null;
	protected MyDataInputFile poiIn = null;
	protected MyDataInputFile gridIn = null;
//	protected MyDataInputFile serviceIn = null;
	private int[] tag = new int[404000];
	private static double Pathlength=0.0;

	public static void main(String[] argv) throws IOException {
		// System.out.println("��������Ҫ����POI������");

		//System.out.println("�����뻮��������������ID���յ�ID��");
		try {
			BufferedWriter out1 = new BufferedWriter(new FileWriter("time.txt"));
			try {
				BufferedWriter out2 = new BufferedWriter(new FileWriter("suiji.txt"));	
		for(int i=0;i<1000;i++){
			/* Random ne1=new Random();
			 s=(long) ne1.nextInt(6105);
			 Random ne2=new Random();
			 d=(long) ne2.nextInt(6105);*/
			
		Main frame = new Main();
		
		String docIndex = "poi.txt";
	    String wordIndex = "wordIndex.txt";
		tmp1 = getWordsFrequency(docIndex,wordIndex);
		
			
			out2.write(s+" "+d+" "+Eujilide);
			for(Integer p:request1){
				out2.write(" "+p);
			}
			
			out2.newLine();
			request1.clear();
			
			out1.write(Pathlength+" "+time+" "+"ms"+" "+mustpoi.size());
			/*for(Node p:mustpoi){
				out1.write(" "+p.getId());
			}*/
			Pathlength=0;
			gridnum=0;
			mustpoi.clear();
			visitpoi.clear();
			out1.newLine();
		}
			out2.flush();
			if (out2 != null)
				out2.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			out1.flush();
			if (out1 != null)
				out1.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//ss	frame.setVisible(true);// ��ͼ֮ǰ������setVisible������ʾ���
		// ʹ��˫���巽��������Ļ����ʾͼ��
		// System.out.println(frame.pois.size()); //��ʾ�ڵ���POI�ĸ���
		/*
		 * ArrayList<String> request = new ArrayList<String>(); Scanner requests = new
		 * Scanner(System.in); for (int i = 0;; i++) { request.add(requests.nextLine());
		 * }
		 */
		
	}

	public Main() {
		
		this.readData(); // ��ȡ�ļ������ݣ����뵽nodes,edges,weights�ȵĶ�����
		setEdgeLength(); // ����ÿ���ߵı߳�
		System.out.println("�������������");
		scanner();
		poi.addAll(services.hashTable.keySet());
		Random ne1=new Random();
		long s1=(long) ne1.nextInt(250);
		Random ne2=new Random();
		long d1=(long) ne2.nextInt(250);
		s=poi.get((int) s1);
		d=poi.get((int) d1);
		request1.addAll(request);
	    Eujilide=nodes.hashTable.get(s).distance(nodes.hashTable.get(d).getX(), nodes.hashTable.get(d).getY());
		start = System.currentTimeMillis();
    	//System.out.println("���㷨��ʼʱ��="+start);
		grid(s, d, request);
		
		//setView(); // ��ͼ��ʾ����
		/*
		 * Scanner ss = new Scanner(System.in); long s1 = ss.nextLong(); Scanner dd =
		 * new Scanner(System.in); long d1 = dd.nextLong();
		 * 
		 * double sp = Astar(nodes.hashTable.get(s1), nodes.hashTable.get(d1));
		 * System.out.println(sp);
		 */
	}
	// ������߳�

	public void setEdgeLength() // �����ÿ���ߵĳ���
	{
		for (Iterator<Long> it = edges.hashTable.keySet().iterator(); it.hasNext();)// ��ȡ��ϣ���е����бߵļ�
		{
			long key = it.next();// ���ݼ��ҵ���ϣ���ж�Ӧ��ֵ
			Node node1 = edges.hashTable.get(key).node1;// ��edge�л�ȡ�ڵ�1��id������id�ҵ��ڵ�1����Ϣ��Ȼ�󴫵�node��
			Node node2 = edges.hashTable.get(key).node2;// ��ȡ�ڵ�2��id
			double length = node2.distance(node1.x, node1.y);// ���ݽڵ�1,2�ľ�γ�ȣ�����߳�
			// System.out.println(length);
			edges.hashTable.get(key).setlength(length);
			// ����key��Ӧ��value�����û�ж�Ӧ��value���򷵻�null
		}

	}

	@Override
	public void update(Graphics g) {
		paint(g);
	}

	/*
	 * readData������ȡ�ļ����е����ݣ����ֱ𱣴���nodes,edges������
	 */
	public void readData() {

		// ���ļ��ж�ȡ�ڵ���Ϣ�浽nodes��
		if (edges == null) {
			nodes = new Nodes();
			try {
				nodeIn = new MyDataInputFile(new DataInputStream(new FileInputStream("node.txt")));
				System.out.println("node catch");
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
				return;
			}
			nodes.read(nodeIn);
		}

		if (nodes.hashTable.size() != 0) {
			try {
				nodeServiceIn = new MyDataInputFile(new DataInputStream(new FileInputStream("poi.txt")));
				String s;
				
				while ((s = nodeServiceIn.readLine()) != null) {
					String[] strArray = s.split("\t");
					int len = strArray.length;
					for (int i = 1; i < len; i++) {
						Node node = nodes.hashTable.get(Long.parseLong(strArray[0]));
						node.getServices().add(Integer.parseInt(strArray[i]));
						pois.put(node.getId(), node);
					}
				}
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
				return;
			}
			
		}
		 if (services == null) {
			 services = new Services();
 			try {
 				serviceIn = new MyDataInputFile(new DataInputStream(new FileInputStream("poi.txt")));
 				System.out.println("service catch");
          
 			} catch (FileNotFoundException e1) {
 				e1.printStackTrace();
 				return;
 			}
 			services.read(serviceIn);
 		}
		// ���ļ��ж���ߵ���Ϣ����edges��
		if (edges == null) {
			edges = new Edges();
			MyDataInputFile in;
			try {
				edgeIn = new MyDataInputFile(new DataInputStream(new FileInputStream("edge.txt")));
				System.out.println("edge catch");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				return;
			}
			edges.read(edgeIn, nodes);

		}

	}

    public static TreeMap<String, TreeMap<String, Integer>> getWordsFrequency(String docIndex , String wordIndex) throws IOException
    { //ͨ��docIndex�ļ��е������ҵ�ÿ���ļ��������ļ��е�����������ͳ��
       TreeMap<String,TreeMap<String,Integer>>  tmp = new TreeMap<String,TreeMap<String,Integer>>();//ͳ��map
       BufferedReader bufr = new BufferedReader(new FileReader(docIndex));//��ȡdocIndex.txt
       BufferedWriter bufw = new BufferedWriter(new FileWriter(wordIndex));//д�뵽wordIndex.txt
    //   BufferedReader bufrDoc = null;
       String docIDandPath = null;
       while( (docIDandPath = bufr.readLine()) != null)
        {
              String[] docInfo = docIDandPath.split(" ");
              String docID = docInfo[0];
              int len = docInfo.length;
			  for (int i = 1; i < len; i++) {
					
	          wordDeal(docInfo[i],docID,tmp);//����docIndex��ȡ����Ӧ�ļ����ݶ���ͳ�ƴ���               
				
			  }
            
        } 
        //��������Ľ��д�뵽wordIndex.txt�ļ���        
        String wordFreInfo = null;
        Set<Map.Entry<String,TreeMap<String,Integer>>> entrySet = tmp.entrySet();
        Iterator<Map.Entry<String,TreeMap<String,Integer>>> it = entrySet.iterator();
        while(it.hasNext())
        {
            Map.Entry<String,TreeMap<String,Integer>> em = it.next();
            wordFreInfo = em.getKey() +" " + em.getValue();
            bufw.write(wordFreInfo);
            bufw.newLine();bufw.flush();
        }
        bufw.close();
        bufr.close();
       return tmp;
    }
    public static void wordDeal(String wordOfDoc,String docID,TreeMap<String,TreeMap<String,Integer>> tmp)
    {
      //  wordOfDoc = wordOfDoc.toLowerCase();//�������
        if(!tmp.containsKey(wordOfDoc))
        {   
          //������ͳ�������״γ��� 
            TreeMap<String , Integer> tmpST = new TreeMap<String , Integer>();
            tmpST.put(docID,1);
            tmp.put(wordOfDoc,tmpST);
        }        
        else
        {//������tmp���ѽ����ڻ�ȡ�õ����ڶ�ӦdocID�г��ִ����������״γ���
         //count = null���򽫣�docID ,1)���뵽tmpST�У��������״γ��֣���count++���ٽ���Ϣ��д��tmpST�С�
         TreeMap<String ,Integer> tmpST = tmp.get(wordOfDoc);
         Integer count = tmpST.get(docID);
         count = ((count == null) ? 1 : count++);
         tmpST.put(docID,count);                
         tmp.put(wordOfDoc,tmpST);  //�����½����д��tmp��   
        }
    }
 /*   public void readService() {
		// ���ļ��ж�ȡ�ڵ���Ϣ�浽nodes��
		if (services == null) {
			services = new Services();
			try {
				gridIn = new MyDataInputFile(new DataInputStream(new FileInputStream("wordIndex.txt")));
			
				System.out.println("services catch");
			} catch (FileNotFoundException e2) {
				e2.printStackTrace();
				return;
			}
			services.read(serviceIn, n);

		}
		
		
		
	}*/

	/*
	 * setView ��������������棬��һ��ͼƬ������İ�ť�Ĳ���
	 */
	/*private void setView() {
		c = new Color[404000];
		
		 * c[0] = Color.red; c[1] = Color.red; c[2] = Color.pink;
		 
		c[0] = Color.black;
		
		 * c[5] = Color.magenta; c[6] = Color.orange;
		 
		scale = Math.max(this.nodes.getMaxX() / this.getMap().getWidth(),
				this.nodes.getMaxY() / this.getMap().getHeight());// ���Ų���������ת���ı���
		// System.out.println(this.nodes.getMaxX()+" "+this.getMap().getWidth()
		// +" "+this.nodes.getMaxY()+" "+this.getMap().getHeight()+" "+scale);
		this.curX = 0 - this.nodes.getMaxX() / 2;
		this.curY = 0;
		this.setLayout(null);
		oimg = this.createImage(1024, 768);// ��Ҫ����ͼ����ص�����Image������
		if (oimg != null) {
			og = oimg.getGraphics();
		}
		setSize(1024, 768);
		add(getKeys());
		this.setVisible(true);
		this.addMouseListener(new MyMouseListener(this));// ��Ӧ �����ק �¼�
		this.addMouseWheelListener(new MyMouseListener(this));// ��Ӧ����������¼�
	}

	
	 * �������ص�ͼ
	 
	protected JLabel getMap() {
		if (map == null) {
			map = new JLabel();
		}
		map.setBounds(1, 1, this.getWidth() - 20, 600);
		// map.setBounds(1, 1, 1000, 600);
		// System.out.println(this.getWidth());
		return map;
	}

	private JPanel getKeys() {
		if (keys == null) {
			keys = new JPanel();
		}

		keys.setName("keys");
		keys.setBounds(0, this.getHeight() - 200, this.getWidth(), 150);
		keys.setLayout(new GridLayout(4, 6));

		buttonUp = new JButton("��");
		buttonUp.addActionListener(this);
		buttonDown = new JButton("��");
		buttonDown.addActionListener(this);
		buttonLeft = new JButton("��");
		buttonLeft.addActionListener(this);
		buttonright = new JButton("��");
		buttonright.addActionListener(this);
		buttonupleft = new JButton("�I");
		buttonupleft.addActionListener(this);
		buttonupright = new JButton("�J");
		buttonupright.addActionListener(this);
		buttondownleft = new JButton("�L");
		buttondownleft.addActionListener(this);
		buttondownright = new JButton("�K");
		buttondownright.addActionListener(this);
		buttongrid = new JButton("����������Ϣ");
		buttongrid.addActionListener(this);

		JLabel blank1 = new JLabel();
		JLabel blank2 = new JLabel();
		JLabel blank3 = new JLabel();
		JLabel blank4 = new JLabel();
		JLabel blank5 = new JLabel();
		JLabel blank6 = new JLabel();
		JLabel blank7 = new JLabel();
		JLabel blank8 = new JLabel();
		JLabel blank9 = new JLabel();
		JLabel blank10 = new JLabel();
		JLabel blank11 = new JLabel();
		JLabel blank12 = new JLabel();
		JLabel blank13 = new JLabel();
		JLabel blank14 = new JLabel();
		JLabel blank15 = new JLabel();

		// keys.add(blank15);
		keys.add(buttongrid);
		keys.add(buttonupleft);
		keys.add(buttonUp);
		keys.add(buttonupright);
		
		 * keys.add(blank6); keys.add(blank3); keys.add(blank1);
		 
		keys.add(blank1);
		keys.add(blank2);
		keys.add(blank3);
		// keys.add(blank8);
		keys.add(buttonLeft);
		keys.add(blank13);
		keys.add(buttonright);
		// keys.add(label5);
		
		 * keys.add(blank2); keys.add(blank1); keys.add(blank1);
		 
		keys.add(blank4);
		keys.add(blank5);
		keys.add(blank6);
		// keys.add(blank14);
		keys.add(buttondownleft);
		keys.add(buttonDown);
		keys.add(buttondownright);
		// keys.add(label2);
		keys.add(blank1);
		keys.add(blank6);
		keys.add(blank7);
		// keys.add(blank14);
		// keys.add(blank13);
		// keys.add(blank14);
		// keys.add(blank15);
		// keys.add(blank8);

		return keys;
	}

	
	 * ÿ�θ��»ᱻ�ظ�����
	 
	public void paint(Graphics g) {
		super.paint(g);
		// System.out.println("paint");
		if (oimg == null) {
			oimg = createImage(1024, 768);
			og = oimg.getGraphics();
		}
		getMap();
		// ��� ��Ļ�ϵĶ���(ʹ���µ�ͼƬ������ԭ����ͼƬ��)
		g.drawImage(oimg, 1, 1, map.getWidth() - 100, map.getHeight() - 2, 0, 0, map.getWidth() - 100,
				map.getHeight() - 2, this);// ���ͼ����ȫ���ػ�����ȫ���ƣ��򷵻�TRUE,OR����FALSE
		paintMap(og);
	}

	
	 * ���Ƶ�ͼ�ĵĵ㣬��
	 
	private void paintMap(Graphics og) {
		// System.out.println(this.scale);
		if (og == null) {
			return;
		}
		double minx, miny, maxx, maxy;// ��ȡ��ͼ�е������С��γ��
		maxx = this.nodes.getMaxX();
		maxy = this.nodes.getMaxY();
		minx = this.nodes.getMinX();
		miny = this.nodes.getMinY();
		// System.out.println(maxx+" "+minx+" "+maxy+" "+miny);
		int xNum = (int) Math.ceil(Math.abs(maxx - minx) / n);// ��������
		int yNum = (int) Math.ceil(Math.abs(maxy - miny) / n);// ��������
		// System.out.println(n+" "+xNum+" "+yNum);

		// �������е�����
		for (double i = minx; i <= maxx + xNum; i += xNum) {
			// System.out.println(i+" "+miny);
			// System.out.println(i+" "+maxy);
			og.setColor(Color.black);
			og.drawLine(getViewX((int) (i)), getViewY((int) (miny)), getViewX((int) (i)), getViewY((int) (maxy)));// graphics,��ֱ��
		}

		// �������еĺ���
		for (double j = miny; j <= maxy + yNum; j += yNum) {
			// System.out.println(j+" "+minx);
			// System.out.println(j+" "+maxx);
			og.setColor(Color.black);
			og.drawLine(getViewX((int) (minx)), getViewY((int) (j)), getViewX((int) (maxx)), getViewY((int) (j)));// graphics,��ֱ��
			for (double i = minx; i <= maxx + xNum; i += xNum) {

			}
		}

		for (Iterator<Long> it = edges.hashTable.keySet().iterator(); it.hasNext();) {
			long key = it.next();
			Edge e = edges.hashTable.get(key);
			// ����ͼ�� ��
			try {
				og.setColor(c[(int) e.getWeight()]);
			} catch (NullPointerException e1) {
				og.setColor(Color.black);
			}

			og.drawLine(getViewX(e.node1.x), getViewY(e.node1.y), getViewX(e.node2.x), getViewY(e.node2.y));// graphics,��ֱ��

			{ // �� ��ͼ�еĽڵ�
				og.setColor(c[(int) e.getWeight()]);
				og.fillOval(getViewX(e.node1.x), getViewY(e.node1.y), 6, 6);
			}
			og.setColor(c[(int) e.getWeight()]);

			// ��ʾÿ���ߵ�Ȩ��
			
			 * ���Ȩ�صĹ�����û���ù�����̫��Ϥ��weight�ļ����Ǳߵ�ID����һ����24Сʱ��Ȩ��
			 * ʦ���Ǹ�ϵͳ�õ��˲�ͬʱ���Ȩ�أ����������棬��������õĻ�Ӧ��Ĭ����2���Ȩ��ֵ�� ����û���ò�ͬʱ���Ȩ�أ��൱��ֻ�����ļ�����ĵ���������
			 
			if (edges.hashTable.get(key) != null) {
				og.drawString(String.valueOf(edges.hashTable.get(key).getWeight()),
						(getViewX(e.node1.x) + getViewX(e.node2.x)) / 2,
						(getViewY(e.node1.y) + getViewY(e.node2.y)) / 2);
			}
		}
	}

	@Override
	public synchronized void repaint() {
		// TODO Auto-generated method stub
		this.oimg = null;
		this.oimg = this.createImage(map.getWidth(), map.getHeight());
		og = null;
		og = oimg.getGraphics();
		super.repaint();
		this.update(og);// update��������paint����
	}

	
	 * ��С
	 
	protected void zoomin() {
		int width = this.map.getWidth();
		int height = this.map.getHeight();
		int midx = this.map.getX() + width / 2;
		int midy = this.map.getY() + height / 2;
		int midx1 = this.getMapX(midx);
		int midy1 = this.getMapY(midy);
		this.setScale(this.getScale() / 2);
		int x1 = midx1 - width * scale / 2;
		int y1 = midy1 - height * scale / 2;
		this.setCurX(x1);
		this.setCurY(y1);
		this.repaint();
	}

	
	 * �Ŵ�
	 
	protected void zoomout() {
		int width = this.map.getWidth();
		int height = this.map.getHeight();
		int midx = this.map.getX() + width / 2;
		int midy = this.map.getY() + height / 2;
		int midx1 = this.getMapX(midx);
		int midy1 = this.getMapY(midy);
		this.setScale(this.getScale() * 2);
		int x1 = midx1 - width * scale / 2;
		int y1 = midy1 - height * scale / 2;
		this.setCurX(x1);
		this.setCurY(y1);
		// this.update(getGraphics());
		this.repaint();
	}

	public int getScale() {
		return scale;
	}

	public void setScale(int scale) {
		if (scale < 1) {
			this.scale = 1;
		} else {

			this.scale = scale;
		}
	}

	public int getViewX(int x) {
		return (x - curX) / scale;
	}

	public int getViewY(int y) {
		return (y - curY) / scale;
	}

	public int getMapX(int x) {
		return x * scale + curX;
	}

	public int getMapY(int y) {
		return y * scale + curY;
	}

	public int getMapX(int x, int scale) {
		return x * scale + curX;
	}

	public int getMapY(int y, int scale) {
		return y * scale + curY;
	}

	public int getCurX() {
		return curX;
	}

	public void setCurX(int curX) {
		this.curX = curX;
	}

	public int getCurY() {
		return curY;
	}

	public void setCurY(int cury) {
		this.curY = cury;
	}

	*//**
	 * ��ͼ���ƶ�
	 *//*
	protected void movedown() {
		// //System.out.println("down button ");
		this.setCurY(curY - this.getMap().getHeight() / 12 * scale);
		// this.repaint();
	}

	protected void moveup() {
		// //System.out.println("up button ");
		this.setCurY(curY + this.getMap().getHeight() / 12 * scale);

		// this.repaint();
	}

	protected void moveleft() {
		// //System.out.println("left button ");
		this.setCurX(curX + this.getMap().getWidth() / 12 * scale);
		// this.repaint();
	}

	protected void moveright() {
		// //System.out.println("right button ");
		this.setCurX(curX - this.getMap().getWidth() / 12 * scale);

		// this.repaint();
	}

	
	 * ��ť��Ӧ�¼�
	 *
	 
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if (e.getSource() == this.buttongrid) {
			// suijiPOI();
			long start,end,time;
			start = System.currentTimeMillis();
	    	System.out.println("���㷨��ʼʱ��="+start);
			grid(s, d, request);
			end = System.currentTimeMillis();
	    	System.out.println("���㷨��ֹʱ��="+end);
	    	time=end-start;
	    	System.out.println("���㷨����ʱ��="+time);
			this.repaint();
		}

		if (e.getSource() == this.buttonUp) {

			moveup();
			this.repaint();
		}
		if (e.getSource() == this.buttonDown) {
			movedown();
			this.repaint();

		}
		if (e.getSource() == this.buttonLeft) {
			moveleft();
			this.repaint();
		}
		if (e.getSource() == this.buttonright) {
			moveright();
			this.repaint();
		}

		if (e.getSource() == this.buttonupleft) {
			moveup();
			moveleft();
			this.repaint();
		}
		if (e.getSource() == this.buttonupright) {
			moveright();
			moveup();
			this.repaint();
		}
		if (e.getSource() == this.buttondownleft) {
			movedown();
			moveleft();
			this.repaint();
		}
		if (e.getSource() == this.buttondownright) {
			movedown();
			moveright();
			this.repaint();
		}
	}
*/
	/*
	 * public void suijiPOI() {
	 * 
	 * try { BufferedWriter out1 = new BufferedWriter( new FileWriter("grid.txt"));
	 * System.out.println(n); for(int i=0;i<n;i++) {
	 * 
	 * int suiji; Random ne=new Random(); suiji=ne.nextInt(6100);
	 * System.out.println(suiji); for (Iterator<Long> it =
	 * nodes.hashTable.keySet().iterator(); it.hasNext();) { //���ݼ�����ȡ��ϣ���ж�Ӧ�ڵ��ֵ Long
	 * key = (Long) it.next(); //���ݼ�����ȡ��ϣ���ж�Ӧ�ڵ��ֵ Node node =
	 * nodes.hashTable.get(key); if(key==suiji) {
	 * //out1.write(nodes.hashTable.get(key)); //out1.write(suiji+" "+ node.x + " "
	 * + node.y); //System.out.println(suiji); int ServicesNum; while(true) {
	 * ServicesNum=new Random().nextInt(10); if(ServicesNum != 0) { break; } }
	 * for(int j=0;j<ServicesNum;j++) { int k=new Random().nextInt(20); //
	 * out1.write(j); if(j==0) { out1.write(suiji+" " +k); }else {
	 * out1.write(" "+k);} // out1.newLine(); System.out.println(suiji+ " " +k); }
	 * 
	 * 
	 * out1.newLine(); } } } out1.flush(); if (out1 != null) out1.close(); }catch
	 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace(); } }
	 */
	/*
	 * �������ţ����ҽ�ÿ���������ź������ڵ����нڵ㽨������ ��������еġ�����������Ϣ����ť�����֮����Ե���grid.txt���ļ��в鿴
	 */
	public void grid(long s, long d, ArrayList<Integer> request) {
		nodes.hashmap = new HashMap<Long, List<Long>>();
		Node currentnode = nodes.hashTable.get(s);
		double minx, miny, maxx, maxy;
		int i, j = 0;
		double sx = 0.0, sy = 0.0, sminx = 0.0, smaxx = 0.0, sminy = 0.0, smaxy = 0.0;
		double dx = 0.0, dy = 0.0, dminx = 0.0, dmaxx = 0.0, dminy = 0.0, dmaxy = 0.0;
		// double a = 0.0;// б��
		double x = 0.0, y = 0.0;
		// long sgrid = 0, dgrid = 0, grid = 0;
		int arraynum = 0;
		ArrayList<Long> array = new ArrayList<Long>();// �洢���������
		ArrayList<Integer> requestcopy = new ArrayList<Integer>();
		requestcopy = (ArrayList<Integer>) request.clone();
		double spd = 0.0, sp = 0.0, pd = 0.0;
		// long n = 1, r = 2;
		long k = 1, m = 1, num = 0, q = 0;
		maxx = this.nodes.getMaxX();
		maxy = this.nodes.getMaxY();
		minx = this.nodes.getMinX();
		miny = this.nodes.getMinY();
		int xNum = (int) Math.ceil(Math.abs(maxx - minx) / n);// �м��
		int yNum = (int) Math.ceil(Math.abs(maxy - miny) / n);// �м��

		for (i = 1; i <= n; i++) {
			for (j = 1; j <= n; j++) {
				num++;
			}
		}
		System.out.println("num=" + num);
		/*
		 * �����ļ���grid.txt������������ź������ڵĽڵ���Ϣ��ŵ����ļ��� �ļ��е�һ��Ϊ������ţ��ڶ���Ϊ�����ڽڵ���ţ��������зֱ�Ϊ�ڵ�ľ�γ��
		 */
		try {
			BufferedWriter out2 = new BufferedWriter(new FileWriter("cost.txt"));
			try {
			BufferedWriter out1 = new BufferedWriter(new FileWriter("grid.txt"));
			for (i = 1; i <= n; i++) { // �����ڵ�ÿһ��
				for (j = 1; j <= n; j++) { // �����ڵ�ÿһ��
					HashMap<Integer,ArrayList<Long>> service=new HashMap();
										//int serviceNum=1;
					List<Long> putlist = new ArrayList<>();
					for (Iterator<Long> it = nodes.hashTable.keySet().iterator(); it.hasNext();)// keyset����ȡ��ϣ�������нڵ�ļ���id��
					{
						Long key = (Long) it.next(); // ���ݼ�����ȡ��ϣ���ж�Ӧ�ڵ��ֵ
						Node node = nodes.hashTable.get(key);
						
						
						// ���ݾ�γ�ȷ�Χ�жϽڵ������ĸ�����
						if (node.x >= minx && node.x <= (minx + xNum) && node.y >= miny && node.y <= (miny + yNum)) {
							// System.out.println(key);
							putlist.add(key);
							if(!node.getServices().isEmpty()){
								
							for(int ss:node.getServices()){
								ArrayList<Long> ser=new ArrayList<Long>();
								ser.add(node.getId());
								
								if(service.keySet().contains(ss)){
									ser.addAll(service.get(ss));
										
									}	
								
							service.put(ss, ser);
							}
							}
							// ����hashmap�ļ�ֵ��ϵ����������ź������ڵĽڵ���Ϣ����������ϵ
							nodes.hashmap.put(k, putlist);// KΪ������ţ�ÿ��������Ŷ�Ӧһ��Arraylist���������ڵĽڵ�ID��ŵ�Arraylist��
							out1.write(k + " " + node.getId() + " " + node.x + " " + node.y + " " + minx + " "
									+ (minx + xNum) + " " + miny + " " + (miny + yNum));
							out1.newLine();
							m++;
						}
						Services.put(k,service);
						
					}
					out2.write(k+" "+service.entrySet());
					//for(long kk:Services.keySet()){
					//out2.write(service.entrySet()+" ");
					//}
					out2.newLine();
					minx = minx + xNum;
					k++;
				}
				minx = this.nodes.getMinX();
				miny = miny + yNum;
			}
			out1.flush();
			if (out1 != null)
				out1.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			out2.flush();
		if (out2 != null)
			out2.close();
		}	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        for(int iii = 0;iii<request.size();iii++){
        	if(nodes.hashTable.get(s).getServices().contains(request.get(iii))||
        			nodes.hashTable.get(d).getServices().contains(request.get(iii)))
        	{
        		request.remove(request.get(iii));
        		iii--;
        	}
        }
		readGrid();
		array.addAll(crossGrid(s, d, xNum, yNum));
		array.addAll(gridExpand(array, request, num));
		System.out.println("�ڵ��Ӧ�ķ������Ϊ" + servicepoi.entrySet());

		// 2019-12-21-���ѻ��ҷ����Ӧ��poi����

		for (int r = 0; r < request.size(); r++) {
			requestpoi.put(request.get(r), new ArrayList<>());
		   /* TreeMap<String, Integer> tmpST=tmp1.get(request.get(r));
			System.out.println(tmp1.get(request.get(r)));*/
			for (Long key : servicepoi.keySet()) {

				ArrayList<Integer> serviceList = nodes.hashTable.get(key).getServices();
				//for (Integer h : serviceList) {
				if (serviceList.contains(request.get(r))) {
						// requestnum++;
				/*if(tmpST.containsKey(key))
				{*/
						requestpoi.get(request.get(r)).add(nodes.hashTable.get(key));
					
				}

			}

		}
		System.out.println("---------------------------------------");
		// System.out.println("�ڵ��Ӧ�ķ������Ϊ" + requestpoi.entrySet());
		Iterator<Entry<Integer, ArrayList<Node>>> requestIterator = requestpoi.entrySet().iterator();
		while (requestIterator.hasNext()) {
			Entry<Integer, ArrayList<Node>> entry = requestIterator.next();
			if (entry.getValue().size() == 1) {
				mustpoi.addAll(entry.getValue());//mustpoi�����ֻ��һ��poi�ṩ�����poi
			}

		}
		if(!mustpoi.isEmpty())
		{
		   for (int w = 0; w < mustpoi.size() - 1; w++) { // ȥ��
		    	for (int z = w + 1; z < mustpoi.size(); z++) {
			    	if (mustpoi.get(w).equals(mustpoi.get(z))) {
			    		mustpoi.remove(z);
				    	z--;
				   }
			    }
		   }

		    for (Node obj : mustpoi) {

			   double Eujilide = obj.distance(nodes.hashTable.get(s).getX(), nodes.hashTable.get(s).getY());

			   mustpoiEujilide.put(obj, Eujilide);
			   queue1.add(Eujilide);
			// System.out.println(obj.getId() );
		    }

		    mustpoi1.add(nodes.hashTable.get(s));//mustpoi1�������s
		    while (!queue1.isEmpty()) {
			   double poll1 = queue1.poll();
			   for (Entry<Node, Double> node2 : mustpoiEujilide.entrySet()) {

				    if (node2.getValue() == poll1) {
				    	mustpoi1.add(node2.getKey());            //mustpoi1���������mustpoi
				    }

			    }
		     }

		int length=mustpoi1.size()-1;
	
		for(int ii=0;ii<length;ii++){
			Pathlength=Pathlength+Astar(mustpoi1.get(ii), mustpoi1.get(ii+1));
		
		   for (Node node2 : rs) {
			   for(int ij=0;ij<request.size();ij++){
			    	if(node2.getServices().contains(request.get(ij))){
					    request.remove(request.get(ij));
					    mustpoi.add(node2);
					    ij--;
				    }
			   }
		   }
		}
		for (int w = 0; w < mustpoi.size() - 1; w++) { // ȥ��
			for (int z = w + 1; z < mustpoi.size(); z++) {
				if (mustpoi.get(w).equals(mustpoi.get(z))) {
					mustpoi.remove(z);
					z--;
				}
			}
		}
		if(request.size()==0){
			
	           Pathlength=Pathlength+Astar(mustpoi1.get(length), nodes.hashTable.get(d));
	            
	           System.out.println("���·������Ϊ"+Pathlength);
	           end = System.currentTimeMillis();
	         //System.out.println("���㷨��ֹʱ��="+end);
	         time=end-start;
	         System.out.println("���㷨����ʱ��="+time);
		}
		else{
		nodeid.clear();
		service.clear();
		array.clear();//���
		Iterator<Entry<Long, Integer>> iterator1 = servicepoi.entrySet().iterator();//���
		  while (iterator1.hasNext()) { 
			  Entry<Long, Integer> entry = iterator1.next(); 
		      iterator1.remove(); 	  
		  }
		  
        Iterator<Entry<Long, Double>> iterator2 = servicegate.entrySet().iterator();
        while (iterator2.hasNext()){
            Entry<Long, Double> entry = iterator2.next();
            iterator2.remove();
        }
        
        System.out.println(".............................................");
        /* 
		System.out.println("array��պ�������СΪ" + array.size());
		System.out.println("nodeid��պ�������СΪ" + nodeid.size());
		System.out.println("service��պ�������СΪ" + service.size());
        System.out.println("��պ��servicepoiΪ" + servicepoi.entrySet());
        System.out.println("��պ��servicegateΪ" + servicegate.entrySet());
        System.out.println(".............................................");
		for (int ii = 0, jj = 1; ii < mustpoi1.size() - 1; ii++, jj++) {
			array.addAll(crossGrid(mustpoi1.get(ii).getId(), mustpoi1.get(jj).getId(), xNum, yNum));
		}*/
        currentnode=mustpoi1.get(length);
        s=mustpoi1.get(length).getId();
		array.addAll(crossGrid(currentnode.getId(), d, xNum, yNum));
		for (Long obj : array) {
			System.out.println("ֱ�߾�����������" + obj);
		}
		
		array.addAll(gridExpand(array, request, num));
		
		while (!request.isEmpty()) {
			int canService=1;
	        Long servicePoi=s;
	        for (Long string1 : servicepoi.keySet()) {
			    if(servicepoi.get(string1)>canService){
			    	canService=servicepoi.get(string1);
			    	servicePoi=string1;
			    }
				}
	        if(canService!=1 && servicePoi!=s){
	        	mustpoi.add(nodes.hashTable.get(servicePoi));
	        	Pathlength=Pathlength+Astar(currentnode, nodes.hashTable.get(servicePoi));
	        	currentnode = nodes.hashTable.get(servicePoi);
	        	
	        }
	        else{
			    for (Long string : servicepoi.keySet()) {
				// System.out.println(string);
				   if (servicepoi.get(string) != 0) {
					   sp = Astar(currentnode, nodes.hashTable.get(string));
					
					   pd = calE(nodes.hashTable.get(string), nodes.hashTable.get(d));
					   spd = sp + pd;
                       servicegate.put(string, spd);
                       servicesp.put(string, sp);
				   }
			    }
			    System.out.println("�ڵ���ʵ��ŷ�Ͼ���֮��Ϊ" + servicegate.entrySet());
			    
			    Queue<Double> queue = new PriorityQueue<>(new Comparator<Double>() {

				@Override
				  public int compare(Double arg0, Double arg1) {
					// TODO �Զ����ɵķ������
					return (int) (arg0 - arg1);
				  }

		    	});
			
			    for (Long string1 : servicepoi.keySet()) {
				    queue.add(servicegate.get(string1));
			    }
			
			    double poll = queue.poll();/// ά��һ���ѱ�֤ÿ��ȡ���Ķ������Ĳ�����
			    Iterator<Entry<Long, Double>> gateInterator = servicegate.entrySet().iterator();// ɾ�����ṩ����Ľڵ�
			    while (gateInterator.hasNext()) {
				    Entry<Long, Double> gateEntry = gateInterator.next();
				// if (gateEntry.getKey().equals(poiKey)) { // ���servicegate�ļ��������ȶ�����Сֵ��Ӧ�ļ�
				    if (gateEntry.getValue() == poll) {
				    	
					    System.out.println(gateEntry.getKey());
					    mustpoi.add(nodes.hashTable.get(gateEntry.getKey()));
					    Pathlength=Pathlength+servicesp.get(gateEntry.getKey());
				        currentnode = nodes.hashTable.get(gateEntry.getKey());// ������Ϊ��ǰ�ڵ�
				        gateInterator.remove();
					// servicepoi.get(gateEntry.getKey()).remove();
				    }
			      }
			    }
					
	            Iterator<Entry<Long, Integer>> its = servicepoi.entrySet().iterator();// ɾ��ѡ�еĽڵ�
			    while (its.hasNext()) {
		    		Entry<Long, Integer> tmp = its.next();
				    if (tmp.getKey().equals(currentnode.getId())) {
				    	its.remove();
				    }
			    }

			    for (int r = 0; r < request.size(); r++) {//ɾ��ѡ�еĵ��ṩ�ķ���
				    if (currentnode.getServices().contains(request.get(r))) {
					    request.remove(r);// ɾ��string�ṩ�ķ���
					    r--;
				    }
			    }
			
			    for (Long key1 : servicepoi.keySet()) {
				     servicenum = 0;
			        for (int r = 0; r < request.size(); r++) {
					    if (nodes.hashTable.get(key1).getServices().contains(request.get(r))) {
						    servicenum++;
										
					    }
				    }
				    servicepoi.put(key1, servicenum);
			    }
					
			    Iterator<Entry<Long, Integer>> it1 = servicepoi.entrySet().iterator();// ɾ�����ṩ����Ľڵ�
			    while (it1.hasNext()) {
				    Entry<Long, Integer> entry = it1.next();
				    if (entry.getValue() == 0) {
					    it1.remove();
							// gateInterator.remove();
				    }
		     	}
					
			    if (servicepoi != null) {
				    System.out.println("�ڵ��Ӧ�ķ������Ϊ" + servicepoi.entrySet());
			    }
		  
			    Iterator<Entry<Long, Double>> iterator3 = servicegate.entrySet().iterator();//���servicegate
		        while (iterator3.hasNext()){
		            Entry<Long, Double> entry = iterator3.next();
		            iterator3.remove();
		        }
		  
		}
		
        for (Node tmp : mustpoi) {
	         System.out.println("mustpoi�ڵ�Ϊ" + tmp.getId());
        }
        
        end = System.currentTimeMillis();

        time=end-start;
        System.out.println("���㷨����ʱ��="+time);

        Pathlength=Pathlength+Astar(currentnode, nodes.hashTable.get(d));
        
        System.out.println("���·������Ϊ"+Pathlength);
		}
 
		}
		else{
		//mustpoiΪ�ջ���request��Ϊ��ʱ
			while (!request.isEmpty()) {
				int canService=1;
		        Long servicePoi=s;
		        for (Long string1 : servicepoi.keySet()) {
				    if(servicepoi.get(string1)>canService){
				    	canService=servicepoi.get(string1);
				    	servicePoi=string1;
				    }
					}
		        if(canService!=1 && servicePoi!=s){
		        	mustpoi.add(nodes.hashTable.get(servicePoi));
		        	Pathlength=Pathlength+Astar(currentnode, nodes.hashTable.get(servicePoi));
		        	currentnode = nodes.hashTable.get(servicePoi);
		        	
		        }
		        else{
				    for (Long string : servicepoi.keySet()) {
					// System.out.println(string);
					   if (servicepoi.get(string) != 0) {
						   sp = Astar(currentnode, nodes.hashTable.get(string));
						
						   pd = calE(nodes.hashTable.get(string), nodes.hashTable.get(d));
						   spd = sp + pd;
	                       servicegate.put(string, spd);
	                       servicesp.put(string, sp);
					   }
				    }
				    System.out.println("�ڵ���ʵ��ŷ�Ͼ���֮��Ϊ" + servicegate.entrySet());
				    
				    Queue<Double> queue = new PriorityQueue<>(new Comparator<Double>() {

					@Override
					  public int compare(Double arg0, Double arg1) {
						// TODO �Զ����ɵķ������
						return (int) (arg0 - arg1);
					  }

			    	});
				
				    for (Long string1 : servicepoi.keySet()) {
					    queue.add(servicegate.get(string1));
				    }
				
				    double poll = queue.poll();/// ά��һ���ѱ�֤ÿ��ȡ���Ķ������Ĳ�����
				    Iterator<Entry<Long, Double>> gateInterator = servicegate.entrySet().iterator();// ɾ�����ṩ����Ľڵ�
				    while (gateInterator.hasNext()) {
					    Entry<Long, Double> gateEntry = gateInterator.next();
					// if (gateEntry.getKey().equals(poiKey)) { // ���servicegate�ļ��������ȶ�����Сֵ��Ӧ�ļ�
					    if (gateEntry.getValue() == poll) {
					    	
						    System.out.println(gateEntry.getKey());
						    mustpoi.add(nodes.hashTable.get(gateEntry.getKey()));
						    Pathlength=Pathlength+servicesp.get(gateEntry.getKey());
					        currentnode = nodes.hashTable.get(gateEntry.getKey());// ������Ϊ��ǰ�ڵ�
					        gateInterator.remove();
						// servicepoi.get(gateEntry.getKey()).remove();
					    }
				      }
				    }
						
		            Iterator<Entry<Long, Integer>> its = servicepoi.entrySet().iterator();// ɾ��ѡ�еĽڵ�
				    while (its.hasNext()) {
			    		Entry<Long, Integer> tmp = its.next();
					    if (tmp.getKey().equals(currentnode.getId())) {
					    	its.remove();
					    }
				    }

				    for (int r = 0; r < request.size(); r++) {//ɾ��ѡ�еĵ��ṩ�ķ���
					    if (currentnode.getServices().contains(request.get(r))) {
						    request.remove(r);// ɾ��string�ṩ�ķ���
						    r--;
					    }
				    }
				
				    for (Long key1 : servicepoi.keySet()) {
					     servicenum = 0;
				        for (int r = 0; r < request.size(); r++) {
						    if (nodes.hashTable.get(key1).getServices().contains(request.get(r))) {
							    servicenum++;
											
						    }
					    }
					    servicepoi.put(key1, servicenum);
				    }
						
				    Iterator<Entry<Long, Integer>> it1 = servicepoi.entrySet().iterator();// ɾ�����ṩ����Ľڵ�
				    while (it1.hasNext()) {
					    Entry<Long, Integer> entry = it1.next();
					    if (entry.getValue() == 0) {
						    it1.remove();
								// gateInterator.remove();
					    }
			     	}
						
				    if (servicepoi != null) {
					    System.out.println("�ڵ��Ӧ�ķ������Ϊ" + servicepoi.entrySet());
				    }
			  
				    Iterator<Entry<Long, Double>> iterator3 = servicegate.entrySet().iterator();//���servicegate
			        while (iterator3.hasNext()){
			            Entry<Long, Double> entry = iterator3.next();
			            iterator3.remove();
			        }
			  
			}
			
	        for (Node tmp : mustpoi) {
		         System.out.println("mustpoi�ڵ�Ϊ" + tmp.getId());
	        }
	        
	        end = System.currentTimeMillis();

	        time=end-start;
	        System.out.println("���㷨����ʱ��="+time);

	        
	        Pathlength=Pathlength+Astar(currentnode, nodes.hashTable.get(d));
	        
	        System.out.println("���·������Ϊ"+Pathlength);
			}
	
}

	public ArrayList<Long> crossGrid(long s, long d, int xNum, int yNum) {
		long sgrid = 0, dgrid = 0, grid = 0;
		double x = 0.0, y = 0.0;
		double sx = 0.0, sy = 0.0, sminx = 0.0, smaxx = 0.0, sminy = 0.0, smaxy = 0.0;
		double dx = 0.0, dy = 0.0, dminx = 0.0, dmaxx = 0.0, dminy = 0.0, dmaxy = 0.0;
		ArrayList<Long> array = new ArrayList<Long>();// �洢���������
		sx = nodes.hashTable.get(s).getX();
		sy = nodes.hashTable.get(s).getY();
		dx = nodes.hashTable.get(d).getX();
		dy = nodes.hashTable.get(d).getY();

		for (Iterator<Long> it = Grids.hashTable.keySet().iterator(); it.hasNext();)// keyset����ȡ��ϣ�������нڵ�ļ���id��
		{
			Long key = (Long) it.next(); // ���ݼ�����ȡ��ϣ���ж�Ӧ�ڵ��ֵ
			ArrayList<Grid> node = Grids.hashTable.get(key);
			for (Grid grid1 : node) {
				if (grid1.getId() == s) {
					sgrid = key;
					array.add(sgrid);
					sminx = grid1.getMinx();
					smaxx = grid1.getMaxx();
					sminy = grid1.getMiny();
					smaxy = grid1.getMaxy();
					System.out.println("������ڵ�����Ϊ��" + sgrid + "������Ϊ��" + sx + "������Ϊ��" + sy);
					System.out
							.println("������ڵ�������x����Ϊ��" + sminx + "��x����Ϊ��" + smaxx + "��y����Ϊ��" + sminy + "��y����Ϊ��" + smaxy);
				}
				if (grid1.getId() == d) {
					dgrid = key;
					array.add(dgrid);
					dminx = grid1.getMinx();
					dmaxx = grid1.getMaxx();
					dminy = grid1.getMiny();
					dmaxy = grid1.getMaxy();
					System.out.println("�յ����ڵ�����Ϊ��" + dgrid + "������Ϊ��" + dx + "������Ϊ��" + dy);
					System.out
							.println("�յ����ڵ�������x����Ϊ��" + dminx + "��x����Ϊ��" + dmaxx + "��y����Ϊ��" + dminy + "��y����Ϊ��" + dmaxy);
				}
			}
		}

		if ((sx > dx && sy > dy) || (sx > dx && sy < dy)) {
			long tmpgrid = sgrid;
			sgrid = dgrid;
			dgrid = tmpgrid;
			double tmpx = sx;
			sx = dx;
			dx = tmpx;
			double tmpy = sy;
			sy = dy;
			dy = tmpy;
			double tmpminx = sminx;
			sminx = dminx;
			dminx = tmpminx;
			double tmpminy = sminy;
			sminy = dminy;
			dminy = tmpminy;
			double tmpmaxx = smaxx;
			smaxx = dmaxx;
			dmaxx = tmpmaxx;
			double tmpmaxy = smaxy;
			smaxy = dmaxy;
			dmaxy = tmpmaxy;

		}

		grid = sgrid;
		if (grid != dgrid) {
			if (sx < dx && sy < dy) {
				double a = (dy - sy) / (dx - sx);
				System.out.println("�����յ����ߵ�б��Ϊ��" + a);
				x = smaxx - sx;
				for (double c = smaxx; c <= dminx;) {
					y = a * x;

					if (y + sy < smaxy) {
						grid = grid + 1;
						if (grid == dgrid) {
							break;
						}
						array.add(grid);

					} else {
						do {
							smaxy = smaxy + yNum;
							grid = grid + n;
							if (grid == dgrid) {
								break;
							}
							if (grid <= n * n)
								array.add(grid);
							else
								break;
						} while (y + sy > smaxy);
						grid = grid + 1;
						if (grid == dgrid) {
							break;
						}
						array.add(grid);
					}
					x = xNum;
					sy = y + sy;
					c = c + xNum;
				}
			} else if (sx < dx && sy > dy) {
				double a = (dy - sy) / (dx - sx);
				System.out.println("�����յ����ߵ�б��Ϊ��" + a);
				x = smaxx - sx;
				for (double c = smaxx; c <= dminx;) {
					y = a * x * (-1);

					if (sy - y > sminy) {
						grid = grid + 1;
						if (grid == dgrid) {
							break;
						}
						array.add(grid);

					} else {
						do {
							sminy = sminy - yNum;
							grid = grid - n;
							if (grid == dgrid) {
								break;
							}
							if (grid > 0)
								array.add(grid);
							else
								break;
						} while (sy - y < sminy);
						grid = grid + 1;
						if (grid == dgrid) {
							break;
						}
						array.add(grid);
					}
					x = xNum;
					sy = sy - y;
					c = c + xNum;
				}
			}else if(sx==dx && sy<dy) {
				while(grid!=dgrid){
					grid=grid+n;
					array.add(grid);
				}
			}else if(sx==dx && sy>dy) {
				while(grid!=dgrid){
					grid=grid-n;
					array.add(grid);
				}
			}
			else if(sx<dx && sy==dy) {
				while(grid!=dgrid){
					grid=grid+1;
					array.add(grid);
				}
			}
			else if(sx>dx && sy==dy) {
				while(grid!=dgrid){
					grid=grid-1;
					array.add(grid);
				}
			}
		}
		/*for (int b = 0; b < array.size(); b++) {
			System.out.println("ֱ�߾���������Ϊ" + array.get(b));// ���������������
		}*/
		for (int w = 0; w < array.size() - 1; w++) { // ȥ��
			for (int z = w + 1; z < array.size(); z++) {
				if (array.get(w).equals(array.get(z))) {
					array.remove(z);
					z--;
				}
			}
		}

		for (Long obj : array) {
			System.out.println("ȥ��ֱ�߾�����������" + obj);
		}

		return array;

	}

	public ArrayList<Long> gridExpand(ArrayList<Long> array, ArrayList<Integer> request, long num) {
		ArrayList<Integer> requestcopy = new ArrayList<Integer>();
		requestcopy = (ArrayList<Integer>) request.clone();
		servicenum=0;
		while(!requestcopy.isEmpty()){
				for (int f = 0; f < array.size(); f++) {
					service.addAll(Services.get(array.get(f)).keySet());
					for(Integer g:Services.get(array.get(f)).keySet()){//
					//for (Grid g : grids.hashTable.get(array.get(f))) {//�ҵ�������������нڵ�
                      if(request.contains(g))
                      {	// System.out.println("��������ĵ��У�"+g.getId());
                    	 for(Long gg:Services.get(array.get(f)).get(g)) {
						     nodeid.add(gg);
                    	 }
                      }
					}
					for (int w = 0; w < nodeid.size() - 1; w++) {
						for (int z = w + 1; z < nodeid.size(); z++) {
							if (nodeid.get(w).equals(nodeid.get(z))) {
								nodeid.remove(z);
								z--;
							}
						}
					}
					// System.out.println();
					for (int p = 0; p < nodeid.size(); p++) {//�ҵ������Ľڵ������ṩ����ĵ�
					//	for (Integer h : nodes.hashTable.get(nodeid.get(p)).getServices()) {
							// System.out.println("��������ķ����У�"+h);
							//service.addAll(nodes.hashTable.get(nodeid.get(p)).getServices());
							for (int r = 0; r < request.size(); r++) {
								if (nodes.hashTable.get(nodeid.get(p)).getServices().contains(request.get(r))) {
									servicenum++;
									servicepoi.put(nodeid.get(p), servicenum);
								}
							}

						
						servicenum = 0;
					}
				
				//	for (int t = 0; t < service.size(); t++) {//ɾ��֮ǰ�õ��Ľڵ��Ѿ��ṩ�ķ���
					
					for (int r = 0; r < requestcopy.size(); r++) {
							if (service.contains(requestcopy.get(r)) ) {
								requestcopy.remove(r);
								r--;
					}
							
				  }
					
				}
				
                if(requestcopy.isEmpty()){
	             break;
                }
                
                
				int arraynum = array.size();
				for (int u = 0; u < arraynum; u++) {//������չ
					Long v = array.get(u);
					if (v - n >= 1) {
						array.add(v - n);
					}
					if (v + n <= num) {
						array.add(v + n);
					}
					if (v - 1 >= 1 && v % n != 1) {
						array.add(v - 1);
					}
					if (v + 1 <= num && v % n != 0) {
						array.add(v + 1);
					}
				}
				/*for (Long b : array) {
					System.out.println("��չ�������Ϊ" + b);
				}*/
				gridnum++;
				for (int w = 0; w < array.size() - 1; w++) {
					for (int z = w + 1; z < array.size(); z++) {
						if (array.get(w).equals(array.get(z))) {
							array.remove(z);
							z--;
						}
					}
				}
			}
		/*for (Long b : array) {
			System.out.println("ȥ�غ������Ϊ" + b);
		}*/
		return array;
	}

	/*public ArrayList<Long> moreExpand(ArrayList<Long> array, long num) {
		int arraynum = array.size();
		for (int u = 0; u < arraynum; u++) {//������չ
			Long v = array.get(u);
			if (v - n >= 1) {
				array.add(v - n);
			}
			if (v + n <= num) {
				array.add(v + n);
			}
			if (v - 1 >= 1 && v % n != 1) {
				array.add(v - 1);
			}
			if (v + 1 <= num && v % n != 0) {
				array.add(v + 1);
			}
		}
		
		for (int w = 0; w < array.size() - 1; w++) {
			for (int z = w + 1; z < array.size(); z++) {
				if (array.get(w).equals(array.get(z))) {
					array.remove(z);
					z--;
				}
			}
		}
		servicenum=0;
		for (int f = 0; f < array.size(); f++) {
			service.addAll(Services.get(array.get(f)).keySet());
			for(Integer g:Services.get(array.get(f)).keySet()){//
			//for (Grid g : grids.hashTable.get(array.get(f))) {//�ҵ�������������нڵ�
              if(request.contains(g))
              {	// System.out.println("��������ĵ��У�"+g.getId());
            	 for(Long gg:Services.get(array.get(f)).get(g)) {
				     nodeid.add(gg);
            	 }
              }
			}
			for (int w = 0; w < nodeid.size() - 1; w++) {
				for (int z = w + 1; z < nodeid.size(); z++) {
					if (nodeid.get(w).equals(nodeid.get(z))) {
						nodeid.remove(z);
						z--;
					}
				}
			}
			// System.out.println();
			for (int p = 0; p < nodeid.size(); p++) {//�ҵ������Ľڵ������ṩ����ĵ�
			//	for (Integer h : nodes.hashTable.get(nodeid.get(p)).getServices()) {
					// System.out.println("��������ķ����У�"+h);
					//service.addAll(nodes.hashTable.get(nodeid.get(p)).getServices());
					for (int r = 0; r < request.size(); r++) {
						if (nodes.hashTable.get(nodeid.get(p)).getServices().contains(request.get(r))) {
							servicenum++;
							servicepoi.put(nodeid.get(p), servicenum);
						}
					}

				
				servicenum = 0;
			}
		}
		for (int w = 0; w < array.size() - 1; w++) { // ȥ��
			for (int z = w + 1; z < array.size(); z++) {
				if (array.get(w).equals(array.get(z))) {
					array.remove(z);
					z--;
				}
			}
		}

		for (Long obj : array) {
			System.out.println("ȥ��ֱ�߾�����������" + obj);
		}

	    return array;
	}*/
	
	public void readGrid() {
		// ���ļ��ж�ȡ�ڵ���Ϣ�浽nodes��
		if (grids == null) {
			grids = new Grids();
			try {
				gridIn = new MyDataInputFile(new DataInputStream(new FileInputStream("grid.txt")));
			
				System.out.println("grid catch");
			} catch (FileNotFoundException e2) {
				e2.printStackTrace();
				return;
			}
			grids.read(gridIn, n);

		}
		
		
		
	}
/*	public void readCost(){
		if (grids == null) {
			grids = new Grids();
			try {
				gridIn = new MyDataInputFile(new DataInputStream(new FileInputStream("cost.txt")));
			
				System.out.println("cost catch");
			} catch (FileNotFoundException e2) {
				e2.printStackTrace();
				return;
			}
			grids.read1(gridIn, n);

		}
	}*/
	public static double calE(Node v1, Node v2) {
		return Math.sqrt(Math.pow(v1.getX() - v2.getX(), 2) + Math.pow(v1.getY() - v2.getY(), 2));
		// Math.sqrt((double)((v1.getX()-v2.getX())*(v1.getX()-v2.getX())+(v1.getY()-v2.getY())*(v1.getY()-v2.getY())));
	}

	/*
	 * private double Astar(Node node1, Node node2) { // TODO �Զ����ɵķ������
	 * 
	 * }
	 */
/*	private long[] AstarPath(Node currentnode, Node node) {
		// TODO �Զ����ɵķ������
		for (Entry<Long, Node> node1 : nodes.hashTable.entrySet()) {
			node1.getValue().setG(0);
			node1.getValue().setF(0);
			node1.getValue().setH(0);
			node1.getValue().setFatherNode(null);
		}
		A text = new A(edges.hashTable);
		text.setTo(node);
		text.setFrom(currentnode);
		LinkedList<Node> result = new LinkedList<>();
		result = text.pathPlaning(currentnode, node);
		double LJ = 0.0;// ������·������
		long rs[] = new long[result.size() + 1];// ������·���Ľڵ�
		rs[0] = currentnode.getId();
		for (int i = 0; i < result.size(); i++) {
			rs[i + 1] = result.get(i).getId();
			LJ = LJ + result.get(i).getG();
			//System.out.print("�õ�Gֵ" + result.get(i).getG());
		}
		System.out.println("���·��Ϊ��");
		for (int i = 0; i < rs.length; i++) {
			System.out.print("   " + rs[i] + "   ");
		}
		System.out.println();
		System.out.print("���·������Ϊ��");
		System.out.println(LJ);
		return rs;
	}*/

	private double Astar(Node currentnode, Node node) {
		// TODO �Զ����ɵķ������
		for (Entry<Long, Node> node1 : nodes.hashTable.entrySet()) {
			node1.getValue().setG(0);
			node1.getValue().setF(0);
			node1.getValue().setH(0);
			node1.getValue().setFatherNode(null);
		}
		A text = new A(edges.hashTable);
		text.setTo(node);
		text.setFrom(currentnode);
		LinkedList<Node> result = new LinkedList<>();
		result = text.pathPlaning(currentnode, node);
		double LJ = 0.0;// ������·������
		rs.clear();
		rs.add(currentnode);
		for (int i = 0; i < result.size(); i++) {
			rs.add(result.get(i));
			LJ = LJ + result.get(i).getG();
			//System.out.print("�õ�Gֵ" + result.get(i).getG());
		}
		System.out.println("���·��Ϊ��");
		for (int i = 0; i < rs.size(); i++) {
			System.out.print("   " + rs.get(i).getId() + "   ");
		}
		System.out.println();
		/*System.out.print("���·������Ϊ��");
		System.out.println(LJ);*/
		return LJ;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO �Զ����ɵķ������
		
	}
}

package com.java.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

public class Times {
	protected Hashtable<Long, Time> hashTable = null;
	protected HashMap<Long, List<Long>> hashmap = null;

	private int num = 0;
	public Times()
	{
		hashTable=new Hashtable<Long, Time>();
	}

	public Time get(long id)
	{
		return  hashTable.get (new Long(id));	
	}//获取节点ID（key）对应的value(id对应的节点信息)
	
	public void read(MyDataInputFile in)
	{
		if(hashTable==null)
		{
			hashTable=new Hashtable<Long, Time>();//如果哈希表为空，则继续新建，继续读取
		}
		for(;;)
		{
			try{
				Time n=new Time(in.readLine()); //逐行读取节点信息
		
			this.hashTable.put(new Long(n.getId()), n);//对外提供接口，将节点id和节点信息建立关系，key为ID,节点信息为value
			if(n.equals(null))//当读取到数据为空，即读取完毕时，跳出循环
			{
				break;
			}
			}catch(java.lang.NullPointerException e)
			{
				break;//如果出错，跳出循环
			}
			num++;
		}
	}

}

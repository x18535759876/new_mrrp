package com.java.test;
import java.util.ArrayList;

public class Time {

	private long id = 0; 

   
	private ArrayList<String> pois = new ArrayList<String>();//提供服务
	
    public Time(String line) {
		
		String s=line;
		
	    String s1[]=s.split(" ");//每一行的数据都存放到一个数组中,以空格分隔
		long pID=Long.parseLong(s1[0]);
	
		for(int i=1;i<s1.length;i++){
			pois.add("p"+s1[i]);
		}
		this.id = pID;
		
		this.pois=pois;
	}

	public Time(long id,ArrayList<String> pois) {
		this.id = id;
	    this.pois=pois;
	}
	
	public long getId() {
		return id;
	}
	public void setID (long newID) {
		id = newID;
	}
	
	public ArrayList<String> getPois() {
		return pois;
	}

	public void setPois(ArrayList<String> pois) {
		this.pois=pois;
	}

	public Object getSpd() {
		// TODO 自动生成的方法存根
		return null;
	}
   

}



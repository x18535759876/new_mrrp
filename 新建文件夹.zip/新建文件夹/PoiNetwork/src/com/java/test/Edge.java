package com.java.test;

public class Edge {
	private int id;//�߱��
	private int weight;//ʵ�ʾ���
	private int edgeName;//������
    Edge next;
    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getEdgeName() {
		return edgeName;
	}

	public void setEdgeName(int edgeName) {
		this.edgeName = edgeName;
	}

	

	public Edge(){
    }
}

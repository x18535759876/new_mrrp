package com.java.test;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;

/**
 * 
 * @author xx
 *
 */
public class Main {
	public static String ss = "";
	public static int pathCount=0;
	public static int k=2;
	public static long ii=1;
	public static final int INF = Integer.MAX_VALUE;
	public static ArrayList<String> Request = new ArrayList<>();//服务需求
	public static ArrayList<String> Poi = new ArrayList<>();//服务需求
	public static Graph graph;//全局变量图
	public static ArrayList<Vertex> Path = new ArrayList<>();//路径表
    public static ArrayList<Vertex> openList = new ArrayList<>();//open表
    public static ArrayList<Vertex> closeList = new ArrayList<>();//close表
    public static Vertex StartNode;
    public static Vertex DestinationNode;
    public static PriorityQueue<Vertex> queue = new PriorityQueue<>(4,new Comparator<Vertex>() {
		//最小优先队列构造器
    	@Override
		public int compare(Vertex v1, Vertex v2) {
    		if(queue.size()>=k) {return 0;}
    		if(v1.getCanServiNum()!=v2.getCanServiNum())
    			return v2.getCanServiNum()-v1.getCanServiNum();
    		else
    			return v1.getG()-v2.getG();
    	}
    });
    static int Scout=0;
	static int r=0;
    private static Nodes nodes = null; // 存放文件中的节点信息。
    protected static MyDataInputFile nodeIn = null;
    private static Times times = null; // 存放文件中的节点信息。
    protected static MyDataInputFile timeIn = null;
    static long s1,d1;
    /**
     * 找给定节点的邻接节点
     * @param g
     * @param currentVertex
     * @return ArrayList
     */
    public static ArrayList<Vertex> findNeighborNodes( Vertex currentNode){
    	ArrayList<Vertex> NeighborList = new ArrayList<>();
    	Edge edge = currentNode.firstEdge;
    	while(edge != null && graph.vertexList.get(edge.getEdgeName()).visited == false) {
    		//计算并更新F值：当前点到邻接点的边权重weight+当前点的F值+neighbor点的F值
    		graph.vertexList.get(edge.getEdgeName()).setF(
    				currentNode.getF() + graph.vertexList.get(edge.getEdgeName()).getF() + getWeight(currentNode, graph.vertexList.get(edge.getEdgeName())));
    		NeighborList.add(graph.vertexList.get(edge.getEdgeName()));
    		edge = edge.next;
    	}
    	return NeighborList;
    }
    
     /**
      * 从局部变量服务中删除已有服务
      * @param request
      * @param node
      * @return
      */
    public static ArrayList<String> removeServices(ArrayList<String> request,Vertex node) {
    	for(int i=0;i<node.services.size();i++) {
    		if(request.contains(node.services.get(i)))
    			request.remove(node.services.get(i));
    	}
    	return request;
    }
    /**
     * 从全局变量服务中移除已有服务
     * @param node
     */
    public static void removeServices(Vertex node) {
    	if(Request.size()==0)
    		return;
    	for(int i=0;i<node.services.size();i++) {
    		if(Request.contains(node.services.get(i)))
    			Request.remove(node.services.get(i));
    	}
    }
    /**
     * 寻找路径
     * @param currentNode
     */
    public static void findPath(Vertex currentNode ) {
    	//服务都满足或者当前返回节点为null时，结束递归
    	if(Request.size() == 0 || currentNode == null)
    		return ;
//    	System.out.println("!!!!!!!!Now located at point:"+currentNode.getVertexName()+"!!!!!!!!!");
    	if(containsServices(Request, currentNode)) {
    		removeServices(Request, currentNode);
    	}
    	findPath(findNextPoint(currentNode));
    }
    
    /**
     * 从当前节点寻找下一节点
     * @param currentNode
     * @return
     */
    public static Vertex findNextPoint(Vertex currentNode) {
    	if(currentNode.services.size() != 0 && currentNode.visited==false) {
			removeServices(currentNode);//将当前节点的服务从Request中移除
		}
    	Path.add(currentNode);
    	ss+=currentNode.getVertexName()+"-->";
//    	System.out.println("request===="+Request);//还需服务
    	ArrayList<Vertex> NeighborList = findNeighborNodes(currentNode);//找到所有近邻节点
   
    	//从邻接点中移除已经走过的结点
    	for(int i=0;i<Path.size();i++) {
    		if(NeighborList.contains(Path.get(i)))
    				NeighborList.remove(Path.get(i));
    	}
//    	if(NeighborList.size()==0) {
//    		graph.vertexList.get(currentNode.getId()-1).visited=true;
//    		Path.remove(Path.size()-1);
//    		return null;
//    	}
//    	if(NeighborList.size()==0) {
//    		System.err.println("null");
//    		return null;
//    	}
    	
    	/**
    	 * 测试
    	 * 输出剩余的邻接节点
    	 */
//    	System.out.println("打印邻接节点：");
//    	for(int i=0;i<NeighborList.size();i++) {
//    		System.out.println(NeighborList.get(i).getVertexName());
//    	}
    	
    	//判断下一个邻接节点是否为最后一个服务点，有则结束程序
    	boolean flag = false;
    	int dis = INF;
    	Vertex temp = new Vertex();
    	//如果某个邻接节点中包含了剩余所有服务则记录该节点（邻接边短的节点）
    	for(int i=0;i<NeighborList.size();i++) {
    		Vertex neighbor = NeighborList.get(i);
    		ArrayList<String> requestTemp = (ArrayList<String>) Request.clone();//难点clone
    		removeServices(requestTemp,neighbor);
    		if(requestTemp.size()==0) {
    			flag = true;
    			temp = neighbor;
    			Vertex v = Path.get(Path.size()-1);//获得路径中的最后一个点
    			int d = getWeight(v, neighbor);//获得边权值
    			if(d < INF && d < dis) {
    				temp = neighbor;
    				dis = d;
    			}
    		}
    	}
    	//flag为真结束程序，打印截至节点
    	if(flag) {
    		Path.add(temp);
//    		System.out.println("|||||||Path end at point:"+temp.getVertexName());
    		return null;
    	}
    	/////否则进行下去
//    	System.out.println("................................................");

    	for(int i=0;i<NeighborList.size();i++) {
    		//对于每一个邻接节点获取一个POI(E值最小)
    		Vertex neighbor = NeighborList.get(i);
    		//test
//    		System.out.println(neighbor.getVertexName()+">>>>>>");
    		//复制Request
    		ArrayList<String> request = (ArrayList<String>) Request.clone();//难点clone
    		ArrayList<Vertex> candidates = new ArrayList<>();
    		if(NeighborList.get(i).services.size()!=0) {
    		//先将邻接节点中有的服务从request中删除
    			request = removeServices(request, NeighborList.get(i));
    		}
    		//将具有剩余服务的兴趣点加入候选集
    		for(int k : graph.vertexList.keySet()) {

    			Vertex v = graph.vertexList.get(k);
    			//忽略邻接节点和走过的点
    			if(v.getId()==neighbor.getId()||Path.contains(v)) 
        			continue;
    			//找到有服务的的点加入候选集
    			if(containsServices(request,v)){  
    				candidates.add(v);
    				//test
//    				System.out.println(v.getVertexName());
    			}
    		}
//    		System.out.println("---------------");
    		Vertex poi = new Vertex();
    		if(candidates.size()==0) {
    			//todo------DeBug这有问题，候选集为空时出现错误异常（数组越界问题）
    		}
    		poi = findMinEInCandidate(candidates,neighbor);//找到候选集中欧式距离最短的POI
//    		System.out.println("E::::"+poi.getE());
    		poi.setH(calH(poi,neighbor));
    		NeighborList.get(i).setG(neighbor.getF()+poi.getH());//计算启发式函数G值=H+E
//    		System.out.println("G::::"+NeighborList.get(i).getG());
    	}
    	return bestNeighborNode(NeighborList);
    }
    
	/**
	 * G值优先
	 * 从候选点中选择最优点
	 * @param neighborList
	 * @return
	 */
    private static Vertex bestNeighborNode(ArrayList<Vertex> neighborList) {
    	int index=0;
    	for(int i=0;i<neighborList.size();i++) {
			queue.add(neighborList.get(i));
		}
    	return queue.poll();
    	
//    	int G = INF;
//		int index = 0;
//		for(int i = 0;i<neighborList.size();i++) {
//			if(neighborList.get(i).getG()<G) {
//				G=neighborList.get(i).getG();
//				index = i;
//			}	
//		}
////		System.out.println("NextPathNode=="+neighborList.get(index).getVertexName()+"================");
//		return neighborList.get(index);
	}
    /**
     * 服务次数优先
     */
//	private static Vertex bestNeighborNode(ArrayList<Vertex> neighborList) {
//		queue.clear();
//		int G = INF;
//		int index = 0;
//		for(int i = 0;i<neighborList.size();i++) {
//			queue.add(neighborList.get(i));
////			if(neighborList.get(i).getG()<G) {
////				G=neighborList.get(i).getG();
////				index = i;
////			}	
//		}
//		System.out.println("NextPathNode=="+neighborList.get(index).getVertexName()+"================");
////		return neighborList.get(index);
//		return queue.peek();
//	}
	/**
	 * 获取两点间的真实距离
	 * @param currentNode
	 * @param neighbor
	 * @return
	 */
	private static int getWeight(Vertex currentNode, Vertex neighbor) {
		if(currentNode.getId()==neighbor.getId())
			return 0;
		Edge edge = new Edge();
		edge = graph.vertexList.get(currentNode.getId()).firstEdge;
        while(edge!=null){	
        	if(graph.vertexList.get(edge.getEdgeName()).getVertexName()==neighbor.getVertexName())
        		return edge.getWeight();
        	edge = edge.next;
        }
        return INF;//两个节点直接不存在直接边
	}
	/**
     * 计算两点之间的欧式距离
     * @param v1
     * @param v2
     * @return H
     */
    public static double calE(Vertex v1,Vertex v2) {
    	return Math.sqrt(Math.pow(v1.getLongitude()-v2.getLongitude(),2)+Math.pow(v1.getLatitude()-v2.getLatitude(),2));
    }
    
	/**
	 * 计算两点间的最短路径距离
	 * @param poi
	 * @param currentNode
	 * @return
	 */
	private static int calH(Vertex poi, Vertex currentNode) {
		return (int)new com.Astar.test.Main().Astar(poi.getId(),currentNode.getId());
//		MatrixUDG mu = new MatrixUDG(graph.Matrix);
//		int [] dist = mu.dijkstr(poi.getId()-1);
//		return dist[currentNode.getId()-1]+dist[DestinationNode.getId()-1];
	}
	/**
	 * 得到两点之间的最短路径，并记录途径节点
	 */
	private static void findNearestPath(Vertex start, Vertex end) {
		MatrixUDG mu = new MatrixUDG(graph.Matrix);
		int []path = mu.dijkstraPath(start.getId()-1, end.getId()-1);
		System.out.print("剩余路径节点：");
		System.out.print(end.getVertexName());
		for(int i=0;i<path.length && path[i]!=-1;i++) {
			pathCount++;
			int p = path[i];
			int id = p+1;
			System.out.print("-->p"+id);
		}
		System.out.println("\n剩余距离="+mu.dist[end.getId()-1]);
	}
	/**
	 * 遍历Path路径节点计算实际距离
	 * @return
	 */
	private static int calRealDistance() {
		int distance=0;
		Edge edge=new Edge();
		System.out.print("计算距离：");
		for(int i=0;i<Path.size()-1;i++) {
//            System.out.print(Path.get(i).getVertexName()+"--->");
            edge=Path.get(i).firstEdge;
            while(edge!=null){	
            	if(graph.vertexList.get(edge.getEdgeName()).getId()==Path.get(i+1).getId()) {
            		
//                    System.out.print("(weight="+edge.getWeight()+")");
//            		pathCount++;
//            		System.out.println(edge.getWeight());
            		distance += edge.getWeight(); 
//            		System.out.println();
//                    //输出节点服务信息
//                    System.out.println(Path.get(i+1).getVertexName()+"'s services:"+Path.get(i+1).services);
            	}
                edge=edge.next;
            }
        }
		return distance;
	}
	/**
	 * 从候选点中寻找欧式距离最短的POI
	 * @param candidates
	 * @param currentNode
	 * @return
	 */
	private static Vertex findMinEInCandidate(ArrayList<Vertex> candidates, Vertex currentNode) {
		if(candidates.size()==0)
			return null;
		double minE = Double.MAX_VALUE;
		int index = 0;
		for(int i=0;i<candidates.size();i++) {
			Vertex v = candidates.get(i);
			double E = calE(v, currentNode)+calE(v, DestinationNode);//当前点到候选点的欧式距离 +候选点到终点的欧式
			if(E < minE) {
				minE = E;
				index = i;
			}
		}
		candidates.get(index).setE(minE);
		return  candidates.get(index);
	}
	/**
	 * 判断节点中是否存在局部变量服务中的服务
	 * @param request2
	 * @param vertex
	 * @return
	 */
	private static boolean containsServices(ArrayList<String> request2, Vertex vertex) {
		int num = 0;
		boolean flag = false;
		if(vertex.services.size()==0) {return flag;}
		for(int i=0;i<vertex.services.size();i++) {
			if(request2.contains(vertex.services.get(i))) {
				num ++;
				flag = true;
			}
		}
		vertex.setCanServiNum(num);
		//System.out.println("hhhhhhh"+vertex.getCanServiNum());
		return flag;
	}
	/**
	 * A*补充路径计算长度
	 */
	public static int AstarPathLen() {
		int len = 0;
		
		for(int i=0;i<Path.size()-1;i++) {
			int d = getWeight(Path.get(i),Path.get(i+1));
			if(d==INF) {
				len+=calH(Path.get(i),Path.get(i+1));
				ss+=new com.Astar.test.Main().Ppath;
//				System.out.println("无边"+calH(Path.get(i),Path.get(i+1))+" ");
			}else{
				len+=d;
				ss+=new com.Astar.test.Main().Ppath;
//				System.out.println("有边"+d+"  ");
			}
		}
		len+=calE(Path.get(Path.size()-1),DestinationNode);
		return len;
	}
	/**
	 * 打印路径
	 */
	public static void printPath() {
		if(Path.size()==0) {
			System.out.println("未找到路径");
			return;
		}
		System.out.print("找到完整路径：Start from ");
		
		for(Vertex v:Path) {
			
			System.out.print(v.getVertexName()+"("+v.getCanServiNum()+")"+"-->");
			if(v.getCanServiNum()!=0) {Scout++;r+=v.getCanServiNum();}
		
		}
		
		System.out.println("End");
		System.out.println("找到服务点个数："+Scout);
		System.out.println("已完成服务个数："+r);
	}
	public static void readData() {

		  // 从文件中读取节点信息存到nodes里
		  if (nodes == null) {
		   nodes = new Nodes();
		   try {
		    nodeIn = new MyDataInputFile(new DataInputStream(new FileInputStream("suiji.txt")));
		    System.out.println("node catch");
		   
		   } catch (FileNotFoundException e1) {
		    e1.printStackTrace();
		    return;
		   }
		   nodes.read(nodeIn);
		  }
		  
		  if (times == null) {
				 times = new Times();
	 			try {
	 				timeIn = new MyDataInputFile(new DataInputStream(new FileInputStream("time.txt")));
	 				System.out.println("time catch");
	          
	 			} catch (FileNotFoundException e1) {
	 				e1.printStackTrace();
	 				return;
	 			}
	 			times.read(timeIn);
	 		}
		  
		 }
	/**
	 * main方法
	 */
    public static void main(String[] args) throws IOException {
    	readData();
    	try {
    		   BufferedWriter out1 = new BufferedWriter(new FileWriter("cost.txt"));
    		   /* for (Iterator<Long> it = nodes.hashTable.keySet().iterator(); it.hasNext();){
   				Long key = (Long) it.next(); // 根据键，获取哈希表中对应节点的值
   				Node node = nodes.hashTable.get(key);*/
   				//poi.add(services.hashTable.keySet());
    		   for(ii=1;ii<=1000;ii++){
   			    s1=nodes.hashTable.get(ii).getS();
   			    d1=nodes.hashTable.get(ii).getD();
   			    for(Integer n:nodes.hashTable.get(ii).getServices()){
   				    Request.add("r"+n);
   			    }
   				
   		Scout=0;
   		Path.clear();
 /*  		Request.add("r5");
   		Request.add("r6");
   		Request.add("r14");
   		Request.add("r17");
   		Request.add("r0");*/
   	
       	CreateGraph createGraph = new CreateGraph();
   	    graph = new Graph();
   	    createGraph.initialGraph(graph);
   		long start,end,time;
       	start = System.currentTimeMillis();
   	    int s = createGraph.vtoe(graph, "p"+s1);
   	    int d = createGraph.vtoe(graph, "p"+d1);
   	    int PathLength=0;
   	    StartNode  = graph.vertexList.get(s);//设置起始点
       	DestinationNode = graph.vertexList.get(d);//设置目标点
       	
       
       /*	System.out.println("起点="+s1);
       	System.out.println("终点="+d1);
       	for(int i=0;i<Request.size();i++) {
       		System.out.println("query="+Request.get(i));
       	}*/
     
	    StartNode  = graph.vertexList.get(s);//设置起始点
    	DestinationNode = graph.vertexList.get(d);//设置目标点
    	if(containsServices(Request, DestinationNode)) {
    		removeServices(DestinationNode);
    		System.out.println("终点服务个数："+DestinationNode.getCanServiNum());
    	}
    	
    	
    	System.out.println("起点："+StartNode.getVertexName()+":："+"终点："+DestinationNode.getVertexName());
    	
    	
    	
    	findPath(StartNode);
    	Path.add(DestinationNode);
    	printPath();
//    	System.out.println("该路径实际距离="+calRealDistance());
    	System.out.println("完整路径："+ss);
    	PathLength=AstarPathLen();
    	System.out.println("Astar距离="+PathLength);
    	if(PathLength==0){
    		PathLength=calH(StartNode,DestinationNode);
    		System.out.println("路径长度为："+PathLength);	
    	}
    	end = System.currentTimeMillis();
    	
        //System.out.println("该算法终止时间="+end);
        time=end-start;
        
        System.out.println("该算法运行时间="+time);
        
      double rs=0.0;
      double chonghe=0.0;
      /*  System.out.println("剩余服务个数="+rs);
        System.out.println("=================================================="+times.hashTable.get(ii).getPois());*/
        out1.write(PathLength+" "+time+" "+"ms"+" "+Scout);
        /*for(Vertex p:Path){
            if(p.getCanServiNum()!=0)
            { 
            out1.write(" "+p.getVertexName());
            Poi.add(p.getVertexName());
            if(times.hashTable.get(ii).getPois().contains(p.getVertexName())){
            	rs++;
            }
            }
        }
        if(Poi.size()==0){
        	chonghe=rs;
        }else{
            chonghe=rs/Poi.size();
        }
        out1.write(" "+chonghe);
        */
   
     Poi.clear();
     Request.clear();
     r=0;
     Scout=0;
     PathLength=0;
     out1.newLine();
     }
     out1.flush();
     if (out1 != null)
      out1.close();
    } catch (IOException e) {
     // TODO Auto-generated catch block
     e.printStackTrace();
    }
    

    }
   
}

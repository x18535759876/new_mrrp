package com.java.test;
import java.io.DataInput;
import java.io.IOException;
public class MyDataInputFile {// implements MyDateInput {
	private DataInput in;//DataInput �ӿ����ڴӶ��������ж�ȡ�ֽ�
	public String readLine()  {
		
		try {
			String s=in.readLine();
			return s;
		} catch (IOException e) {
			
			return null;
		}
		
	}
	public MyDataInputFile(DataInput in)
	{
		this.in=in;
	}
}

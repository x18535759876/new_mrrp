package com.java.test;

import java.util.ArrayList;

public class Vertex {
	private int id;//��� 
	private double longitude;//����x
	private double latitude;//γ��y
	boolean visited = false;//���ʱ��
	private int F=0;
	private int G=0;
	private int H=0;
	private double E=0;
	private int canServiNum=0;
	
	ArrayList<String> services = new ArrayList<>();//�ṩ����

	
	private String vertexName;
    Edge firstEdge=new Edge();
        

    public void calcF() {
    	this.F = this.G + this.H;
    }
    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public String getVertexName() {
		return vertexName;
	}

	public void setVertexName(String vertexName) {
		this.vertexName = vertexName;
	}

	
	public int getF() {
		return F;
	}

	public void setF(int f) {
		F = f;
	}

	public int getG() {
		return G;
	}

	public void setG(int g) {
		G = g;
	}

	public int getH() {
		return H;
	}

	public void setH(int h) {
		H = h;
	}

	public double getE() {
		return E;
	}

	public void setE(double e) {
		E = e;
	}

	public Vertex(){
    }
	
	public int getCanServiNum() {
		return canServiNum;
	}

	public void setCanServiNum(int canServiNum) {
		this.canServiNum = canServiNum;
	}

	public Vertex(double longitude,double latitude) {
		this.longitude = longitude;
		this.latitude = latitude;
	}
}

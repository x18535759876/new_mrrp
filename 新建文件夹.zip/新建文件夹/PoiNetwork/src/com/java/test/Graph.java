package com.java.test;

import java.util.HashMap;

public class Graph {
//	ArrayList<Vertex> vertexList=new ArrayList<Vertex>();
	HashMap<Integer, Vertex> vertexList = new HashMap<>(); 
    private int vertexNum=0;
    private int edgeNum=0;
    int [][] Matrix;//�ڽӾ���
    
    public int getVertexNum() {
		return vertexNum;
	}

	public void setVertexNum(int vertexNum) {
		this.vertexNum = vertexNum;
	}

	public int getEdgeNum() {
		return edgeNum;
	}

	public void setEdgeNum(int edgeNum) {
		this.edgeNum = edgeNum;
	}

	

	public Graph(){}
}

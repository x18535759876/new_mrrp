package com.java.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

	
	/**
	 * ͨ�������ߺ͵�Ķ���������ͼ
	 * @author King
	 */
	public class CreateGraph {
		final int INF = Integer.MAX_VALUE; 
	    /**
	     * ���ݶ�����ϢString�����رߵĶ���
	     * @param graph ͼ
	     * @param str ��������
	     * @return ���ص��Ǳ߶���ı�ǩ
	     */
	    public int vtoe(Graph graph,String str){
	        for (int key : graph.vertexList.keySet()){
	            if(graph.vertexList.get(key).getVertexName().equals(str))
					return key;
	        	}
//	        for(int i=0;i<graph.getVertexNum();i++){
//	            if(graph.vertexList.get(i).getVertexName().equals(str)){
//	                return i;
//	            }
//	        }
	        return -1;
	    }

	    /**
	     * �ú�������ͼ�ĳ�ʼ����ʵ��
	     * @param graph ͼ
	     * @throws IOException 
	     */
	    public void initialGraph(Graph graph) throws IOException{
	    	
	  ////////////////////////////////////////////////////////����ڵ���Ϣ
	    	FileReader fr1=new FileReader("H:/test/nodes.txt");
	    	BufferedReader br1=new BufferedReader(fr1);
	    	int vCount=0;
	    	String line1 = null;
	    	String[] arrs1=null;
	    	while((line1=br1.readLine())!=null) {
	    		arrs1 = line1.split(" ");
	    		 Vertex vertex=new Vertex();
	    		 vertex.setId(Integer.parseInt(arrs1[0]));
	    		 vertex.setVertexName("p"+arrs1[0]);
	    		 vertex.setLongitude(Integer.parseInt(arrs1[1]));
	    		 vertex.setLatitude(Integer.parseInt(arrs1[2]));
	    		 vertex.firstEdge = null;
	    		 graph.vertexList.put(Integer.parseInt(arrs1[0]),vertex);
	    		 vCount++;
	    	}
	    	graph.setVertexNum(vCount);
//	    	System.out.println(vCount);
	    	br1.close();
	    	fr1.close();
	    	
	   //////////////////////////////////////////////////////////��ʼ���ڽӾ���
	    	graph.Matrix = new int[graph.getVertexNum()][graph.getVertexNum()];
	    	for(int i=0;i<graph.getVertexNum();i++) {
	    		for(int j=0;j<graph.getVertexNum();j++) {
	    			if(i==j)
	    				graph.Matrix[i][j]=0;
	    			else
	    				graph.Matrix[i][j]=INF;
	    		}
	    	}
	 /////////////////////////////////////////////////////////�������Ϣ
	    	FileReader fr2=new FileReader("H:/test/edgetab.txt");
	    	BufferedReader br2=new BufferedReader(fr2);
	    	int eCount=0;
	    	String line2 = null;
	    	String[] arrs2=null;
	    	while((line2=br2.readLine())!=null) {
//	    		System.out.println(line2);
	    		arrs2 = line2.split(" ");
	    		String preV="p"+arrs2[1];
	            String folV="p"+arrs2[2];
	            int v1=vtoe(graph,preV);
	            int v2=vtoe(graph,folV);
//	            graph.Matrix[v1][v2]=Integer.parseInt(arrs2[3]);
//	            graph.Matrix[v2][v1]=Integer.parseInt(arrs2[3]);
	            if(v1==-1 || v2==-1)
	                System.out.println("���붥�����ݴ���");

	//���������ͼ�����ĺ��ģ��������
	            Edge edge1=new Edge();
	            edge1.setEdgeName(v2);
	            edge1.setWeight(Integer.parseInt(arrs2[3]));
	            edge1.next=graph.vertexList.get(v1).firstEdge;
	            graph.vertexList.get(v1).firstEdge=edge1;
	            
	 //	          ���������ϱ��ǹ�������ͼ�����ӱ��ǹ�������ͼ
	            Edge edge2=new Edge();
	            edge2.setWeight(Integer.parseInt(arrs2[3]));
	            edge2.setEdgeName(v1);
	            edge2.next=graph.vertexList.get(v2).firstEdge;
	            graph.vertexList.get(v2).firstEdge=edge2;
	            eCount++;
	        }
	    	graph.setEdgeNum(eCount);
//	    	System.out.println(eCount);
	    	br2.close();
	    	fr2.close();
	    	
	  /////////////////////////////////////////////////////////����ڵ�ķ�����Ϣ
	    	  /////////////////////////////////////////////////////////输入节点的服务信息
	    	FileReader fr3=new FileReader("H:/test/services.txt");
	    	BufferedReader br3=new BufferedReader(fr3);
	    	
	    	String line3="";
	    	String[] arrs3=null;
	    	while((line3=br3.readLine())!=null) {
	    		arrs3=line3.split("\t");
	    		int v = vtoe(graph,"p"+arrs3[0]);
	    		if(v==-1)
	                System.out.println("输入顶点信息错误！");
	    		//String[] str = arrs3[1].split(" ");
	    		for(int i=1;i<arrs3.length;i++) {
	    			graph.vertexList.get(v).services.add("r"+arrs3[i]);
	    		}
	    		//System.out.println(graph.vertexList.get(v).services);
	    	}
	    	br3.close();
	    	fr3.close(); 	
	    }
	
	    /**
	     * ���ͼ���ڽ������ʾ
	     * @param graph ͼ
	     */
	    
	    public void outputGraph(Graph graph){
	        Edge edge=new Edge();
	        for(int key : graph.vertexList.keySet()) {
//	        for(int i=1;i<graph.getVertexNum();i++){
	            System.out.print(graph.vertexList.get(key).getVertexName());
	            edge=graph.vertexList.get(key).firstEdge;
	            while(edge!=null){	
	                System.out.print("-->"+graph.vertexList.get(edge.getEdgeName()).getVertexName());
	                //�����Ȩ��
	                System.out.print("(weight="+edge.getWeight()+")");
	                edge=edge.next;
	            }
	            System.out.println();
	            //����ڵ������Ϣ
	            System.out.println("services:"+graph.vertexList.get(key).services);
	        }
	    }
	    public void outputMatrix(Graph graph) {
	    	//��ӡ�ڽӾ���
	    	for(int i=0;i<graph.getVertexNum();i++) {
	    		for(int j=0;j<graph.getVertexNum();j++) {
	    			if(graph.Matrix[i][j]==INF)
	    				System.out.print("INF ");
	    			else
	    				System.out.print(graph.Matrix[i][j]+" ");
	    		}
	    		System.out.println();
	    	}
	    }
	    
	    public static void main(String[] args) throws IOException {
	        CreateGraph createGraph=new CreateGraph();
	        Graph graph=new Graph();
	        createGraph.initialGraph(graph);
	        createGraph.outputGraph(graph);
	    }
	}


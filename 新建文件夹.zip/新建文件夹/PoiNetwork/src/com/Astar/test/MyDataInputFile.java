package com.Astar.test;
import java.io.DataInput;
import java.io.IOException;
public class MyDataInputFile {// implements MyDateInput {
    private DataInput in;//DataInput 接口用于从二进制流中读取字节
    public String readLine()  {

        try {
            String s=in.readLine();
            return s;
        } catch (IOException e) {

            return null;
        }

    }
    public MyDataInputFile(DataInput in)
    {
        this.in=in;
    }
}

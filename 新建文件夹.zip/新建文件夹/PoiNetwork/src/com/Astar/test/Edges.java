package com.Astar.test;
import java.util.Hashtable;

public class Edges {
	
	protected Hashtable<Long,Edge> hashTable =  null;
	public void read(MyDataInputFile in, Nodes nodes) 
	{
		int i = 0;
		if(hashTable==null)
		{
			hashTable=new Hashtable<Long,Edge>();
		}
		for(;;)
		{
			try{
				
				Edge e=new Edge(in.readLine(),nodes);
			this.hashTable.put(new Long(e.getId()), e);
			if(e.equals(null))//equals������������e�Ƿ�Ϊ��
			{
				break;
			}
			}
			catch(java.lang.NullPointerException e)
			{
				break;
			}
			
		}
	}
}

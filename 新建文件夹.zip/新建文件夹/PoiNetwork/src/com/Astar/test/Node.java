package com.Astar.test;
import java.util.ArrayList;

public class Node {
	protected int x = 0;
	protected int y = 0;
	private long id = 0; 
	private int nodeType = 0;
	private double g;
    private double h;
    private double f;
    private Node fatherNode;
    public  Node(){}
	private ArrayList<Integer> services = new ArrayList<Integer>();//�ṩ����
	
    public Node(String line) {
		
		String s=line;
		
	    String s1[]=s.split(" ");//ÿһ�е����ݶ���ŵ�һ��������,�Կո�ָ�
		long pID=Long.parseLong(s1[0]);
		int x=(int)(Double.parseDouble(s1[1]));
		int y=(int)(Double.parseDouble(s1[2]));
		this.id = pID;
		this.x = x;
		this.y = y;
	}

    public Node(int id,int x,int y)
    {
        this.id = id;
        this.x = x;
        this.y = y;
        g = 0;
        h = 0;
        f = 0;
        fatherNode = null;
    }
    public Node (long id, int x, int y)
	{
		this.id = id;
		this.x = x;
		this.y = y;
	
	}

	public Node(long id, int x, int y, String name) {
		this.id = id;
		this.x = x;
		this.y = y;
	
	}
	
	public long getId() {
		return id;
	}
	public void setID (long newID) {
		id = newID;
	}
	public int getX()
	{
		return x;
	}
	public void setX(int x)
	{
		this.x = x ;
	}
	public int getY()
	{
		return y;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	public void setNodeTye(int nodeType)
	{
		this.nodeType = nodeType;
	}
	public int getNodeType()
	{
		return nodeType;
		
	}
	public double distance (int x,int y)
	{

		return (Math.sqrt((double)((this.x-x)*(this.x-x)+(this.y-y)*(this.y-y))));
		//
	}

	public ArrayList<Integer> getServices() {
		return services;
	}

	public void setServices(ArrayList<Integer> services) {
		this.services = services;
	}

	public Object getSpd() {
		// TODO �Զ����ɵķ������
		return null;
	}
    public double getG() {
        return g;
    }

   
    public double getH() {
        return h;
    }

    public double getF() {
        return f;
    }

    
    public void setG(double g) {
        this.g = g;
    }
    public void setF(double f) {
        this.f = f;
    }
    public void setH(double h) {
        this.h = h;
    }

    public void setFatherNode(Node fatherNode) {
        this.fatherNode = fatherNode;
        // this.g = this.calG(fatherNode);
		//this.h = this.distanceTo(fatherNode);
		//this.f = this.g + this.h;
    }

    public Node getFatherNode() {
        return fatherNode;
    }

}


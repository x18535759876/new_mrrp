package com.Astar.test;
import java.io.DataInput;
import java.io.IOException;

public class Edge {
	
	private long id = 0;
	protected Node node1 = null;
	protected Node node2 = null;
	private short edgeClass = 0;	
	private double length = 0;
    private long weight=0;
    
	public Edge(String line,Nodes nodes)
	{
		String s=line;	
		 String s1[]=s.split(" ");
		 long eID=Long.parseLong(s1[0]);//���ļ��л�ȡ�ߵ�ID
		 long id1=Long.parseLong(s1[1]);//���ļ��л�ȡһ���˵��ID
		 long id2=Long.parseLong(s1[2]);//���ļ��л�ȡ��һ���˵��ID
		 long weight=Integer.parseInt(s1[3]);
		 
			Node pNode1 = nodes.get(id1);
			Node pNode2 = nodes.get(id2);
			this.id=eID;
			this.weight=weight;
			this.node1=pNode1;
			this.node2=pNode2;
	}
	public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}
	public double getlength() { return length; }

	public void setlength(double length) {
		this.length = length;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	

}

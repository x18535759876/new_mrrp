package com.Astar.test;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map.Entry;;
public class A 
{
	private HashSet<Node> openlist = new HashSet<>();
	/*private HashSet<Node> edge = new HashSet<>();*/
	private HashSet<Node> closelist = new HashSet<>();
/*	private ArrayList<Integer[]> datanodelist = new ArrayList<>();
    private ArrayList<Integer[]> dataedgelist = new ArrayList<>();*/
    private Hashtable<Long,Node> datenodemessage = new Hashtable<>();//�洢���ݵ���Ϣ�Ĺ�ϣ��
    private Hashtable<Long,Edge> dataedgemessage;//�洢����Ϣ�Ĺ�ϣ��
    private Node to = new Node();
    private Node from = new Node();
    
    //���캯��
    public A(Hashtable<Long,Edge> hashTable){
	   this.dataedgemessage=hashTable;
    }
    public void setTo(Node to) 
    {
    	this.to = to;
    }  
    public void setFrom(Node from) 
    {
    	this.from = from;
    }  
   /* public ArrayList<Integer[]> getDatanodelist()
    {
    	return datanodelist;
    }*/
   /* public void setEdge(HashSet<Node> dataedge) 
    {
    	this.edge = dataedge;
    }
    */
    public void setDataNodeList(Hashtable<Long,Node> datenodemessage) 
    {
    	this.datenodemessage = datenodemessage;
    }
    
    public void setDataEdgeList(Hashtable<Long,Edge> dataedgemessage) 
    {
    	this.dataedgemessage = dataedgemessage;
    }
    
 
	public HashSet<Node> getNeighborrs(Node node)
	{
		HashSet<Node> neighbors = new HashSet<>();
		for(Entry<Long, Edge> entry :dataedgemessage.entrySet())
		{
			if(entry.getValue().node1.getId() == node.getId())
			{
				neighbors.add(entry.getValue().node2);
			}
			else if(entry.getValue().node2.getId() == node.getId()) 
			{
				neighbors.add(entry.getValue().node1);
			}
		}
		return neighbors ;
	}
	
	public Node getBestNode(HashSet<Node> find) 
	{
		Node best = null;
		double bestF = Double.MAX_VALUE;
		for(Node node : find) 
		{
			if(node.getF()<bestF)
			{
				bestF = node.getF();
				best = node;
			}
		}
		return best;
	}
	
	public Node getNodeFromList(Node m,HashSet<Node> openlist) 
	{
		Node findNode = null;
		for(Node fn:openlist) 
		{
			if(fn.getId() == m.getId()) 
			{
				findNode = fn;
			}
		}
		return findNode;
	}
	
	public LinkedList<Node> getResult(Node from ,Node to)
	{
		LinkedList<Node> result = new LinkedList<Node>();
		Node node = to;
		while(!node.equals(from)) 
		{
			if(node.getFatherNode() == null)
			{
				return null;
			}
			result.push(node);
			
			node = node.getFatherNode();
			
		}
		return result;
		
	}
	
	public boolean contince(Node node,HashSet<Node> list) 
	{
		for(Node innode : list) 
		{
			if(innode.getId() == node.getId())
			{
				return true;
			}
		}
		return false;
	} 
	
	public double distanceTo(Node x) 
	{
		return Math.sqrt((x.getX() - to.getX())*(x.getX() - to.getX()) + (x.getY() - to.getY())*(x.getY() - to.getY()));
	}
	
	public LinkedList<Node> pathPlaning(Node from,Node to)
	{
		openlist.clear();
		closelist.clear();
		openlist.add(from);
		while(!openlist.isEmpty())
		{
			Node currentNode = getBestNode(openlist);
			HashSet<Node> neighbors = getNeighborrs(currentNode);
			if(contince(to,neighbors)) 
			{
				
				double distance = 0.0;
		
				for(Entry<Long, Edge> entry :dataedgemessage.entrySet())
				{
					
					if(entry.getValue().node1.getId() == currentNode.getId() && entry.getValue().node2.getId() == to.getId() ) 
					{
						distance = entry.getValue().getWeight() ;
						break;
					}
					else if(entry.getValue().node1.getId() == to.getId() && entry.getValue().node2.getId() == currentNode.getId())
					{
						distance = entry.getValue().getWeight() ;
						break;
					}
				}
				double g =  distance;
				to.setFatherNode(currentNode);
				to.setG(g);
				break;
			}
			for(Node neighbor:neighbors) 
			{

				if(contince(neighbor,closelist)) 
				{
					continue;
				}
				if(contince(neighbor,openlist)) 
				{
					Node n =  getNodeFromList(neighbor,openlist);
					double distance = 0.0;
					for(Entry<Long, Edge> entry :dataedgemessage.entrySet()) 
					{
						if(entry.getValue().node1.getId() == neighbor.getId() && entry.getValue().node2.getId() == currentNode.getId()) 
						{
							distance = entry.getValue().getWeight();
							break;
						}
						else if(entry.getValue().node1.getId() == currentNode.getId() && entry.getValue().node2.getId() == neighbor.getId() )
                        {
	                    distance = entry.getValue().getWeight();
	                    break;
                        }
					}
					double g = neighbor.getG() + distance;
					if(g < n.getG()) 
					{
						neighbor.setFatherNode(currentNode);
						neighbor.setG(g);
						openlist.add(neighbor);
						
					}
				}
				else 
				{
					double distance = 0.0;
					for(Entry<Long, Edge> entry :dataedgemessage.entrySet()) 
					{
						if(entry.getValue().node1.getId() == neighbor.getId() && entry.getValue().node2.getId() == currentNode.getId() ) 
						{
							distance = entry.getValue().getWeight();
							break;
						}
						else if(entry.getValue().node1.getId() == currentNode.getId() && entry.getValue().node2.getId() == neighbor.getId())
                        {
	                        distance = entry.getValue().getWeight();
	                        break;
                        }
					}
					double g = neighbor.getG() + distance;
					neighbor.setFatherNode(currentNode);
					neighbor.setG(g);
					neighbor.setH(distanceTo(neighbor));
					neighbor.setF(g+distanceTo(neighbor));
					openlist.add(neighbor);
				}
			}
			closelist.add(currentNode);
			openlist.remove(currentNode);
		}
		
		return getResult(from,to);
	}
}

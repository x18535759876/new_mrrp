package com.Astar.test;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Map.Entry;

public class Main {
	protected static MyDataInputFile edgeIn = null; // 一行一行读取文件时就不用每次都去文件中读取了，减少了IO次数。
	protected static MyDataInputFile nodeIn = null;
	private Nodes nodes = null; // 存放文件中的节点信息。
	private Edges edges = null; // 将文件中的节点信息读取到nodes中后
	static LinkedList<Node> result = new LinkedList<>();
	ArrayList<Node> rs = new ArrayList<Node>();
	public String Ppath="";
	public double Astar(long s,long d) {
		Ppath="";
			if (nodes == null) {
				nodes = new Nodes();
				try {
					nodeIn = new MyDataInputFile(new DataInputStream(new FileInputStream("H:/test/nodes.txt")));
//					System.out.println("node catch");
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				
				}
				nodes.read(nodeIn);
			}
	        if (edges == null) {
				edges = new Edges();
				MyDataInputFile in;
				try {
					edgeIn = new MyDataInputFile(new DataInputStream(new FileInputStream("H:/test/edgetab.txt")));
//					System.out.println("edge catch");
				} catch (FileNotFoundException e) {
					e.printStackTrace();
					
				}
				edges.read(edgeIn, nodes);

			}
	        
	    A text = new A(edges.hashTable);
		for (Entry<Long, Node> node1 : nodes.hashTable.entrySet()) {
				node1.getValue().setG(0);
				node1.getValue().setF(0);
				node1.getValue().setH(0);
				node1.getValue().setFatherNode(null);
		}
			
	
      
        Node currentnode=nodes.hashTable.get(s);
        Node node=nodes.hashTable.get(d);
    //    System.out.println(currentnode.getId()+"点坐标为 "+node.getId());
        
    	/*text.setFrom(currentnode);
		text.setTo(node);*/
	

		result = text.pathPlaning(currentnode, node);
		double LJ = 0.0;// 存放最短路径长度
		
		rs.add(currentnode);
		for (int i = 0; i < result.size(); i++) {
			rs.add(result.get(i));
			LJ = LJ + result.get(i).getG();
			//System.out.print("该点G值" + result.get(i).getG());
		}
//		System.out.println("最佳路径为：");
		for (int i = 0; i < rs.size(); i++) {
			Ppath+="-->p"+rs.get(i).getId();
//			System.out.print("   " + rs.get(i).getId() + "   ");
		}
		System.out.println(Ppath);
//		System.out.println();
		/*System.out.print("最佳路径长度为：");
		System.out.println(LJ);*/
		return LJ;
	}
	
//	public Main() {
//		
//		    Scanner in = new Scanner(System.in);
//	        System.out.println("请输入路径的起点�?");
//	        //2019-12-23-16:16
//	        int begennode = in.nextInt();
//	        System.out.println("请输入路径的终点�?");
//	        int endnode = in.nextInt();
//	       // System.out.println(begennode+" "+endnode);
//	        
//	        double LJ = 0.0;
//		    LJ=Astar(begennode,endnode);
//
//	        System.out.println();
//	        System.out.print("�?佳路径长度为�?");
//	        System.out.println(LJ);
//	}
//    public static void main(String[] args) {
//    	Main frame = new Main();
//    }

}
